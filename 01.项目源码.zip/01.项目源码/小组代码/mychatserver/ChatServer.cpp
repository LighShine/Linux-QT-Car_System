#include "ChatServer.h"
#include <QDebug>
#include <QVBoxLayout>

ChatServer::ChatServer(QWidget *parent)
    : QWidget(parent), tcpServer(new QTcpServer(this))
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    statusLabel = new QLabel("Server is not running", this);
    layout->addWidget(statusLabel);

    clientListWidget = new QListWidget(this);
    layout->addWidget(clientListWidget);

    startButton = new QPushButton("Start Server", this);
    layout->addWidget(startButton);

    connect(startButton, &QPushButton::clicked, this, &ChatServer::startServer);
    connect(tcpServer, &QTcpServer::newConnection, this, [this]() {
        QTcpSocket *clientSocket = tcpServer->nextPendingConnection();
        connect(clientSocket, &QTcpSocket::readyRead, this, &ChatServer::onReadyRead);
        connect(clientSocket, &QTcpSocket::disconnected, this, &ChatServer::onDisconnected);

        qDebug() << "New client connected: " << clientSocket->peerAddress().toString();
        clientListWidget->addItem(clientSocket->peerAddress().toString());
    });

    offlineMessages = QMap<QString, QList<QString>>();

    setLayout(layout);
    setWindowTitle("Chat Server");
    resize(400, 300);
}

ChatServer::~ChatServer()
{
    for (QTcpSocket* socket : clients.values()) {
        socket->disconnectFromHost();
        socket->deleteLater();
    }
    clients.clear();
}

void ChatServer::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket *clientSocket = new QTcpSocket(this);

    if (!clientSocket->setSocketDescriptor(socketDescriptor)) {
        qDebug() << "Failed to set socket descriptor";
        clientSocket->deleteLater();
        return;
    }

    connect(clientSocket, &QTcpSocket::readyRead, this, &ChatServer::onReadyRead);
    connect(clientSocket, &QTcpSocket::disconnected, this, &ChatServer::onDisconnected);

    qDebug() << "New client connected: " << socketDescriptor;
}

void ChatServer::onReadyRead()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket *>(sender());
    if (!clientSocket) return;

    while (clientSocket->canReadLine()) {
        QString message = QString::fromUtf8(clientSocket->readLine()).trimmed();
        qDebug() << "Received message: " << message;

        if (message.startsWith("REGISTER:")) {
            QString account = message.split(":")[1];
            clients[account] = clientSocket;
            qDebug() << "Registered client with account: " << account;
            sendToClient(clientSocket, "Welcome, " + account + "!");
            updateClientList();

            if (offlineMessages.contains(account)) {
                for (const QString &offlineMessage : offlineMessages[account]) {
                    sendToClient(clientSocket, offlineMessage);
                }
                offlineMessages.remove(account);
            }
        } else {
            QStringList parts = message.split(":");
            if (parts.size() == 3) {
                QString senderAccount = parts[0];
                QString receiverAccount = parts[1];
                QString msgContent = parts[2];

                if (clients.contains(receiverAccount)) {
                    QTcpSocket *receiverSocket = clients[receiverAccount];
                    sendToClient(receiverSocket, senderAccount + ": " + msgContent);
                } else {
                    offlineMessages[receiverAccount].append(senderAccount + ": " + msgContent);
                    sendToClient(clientSocket, "User " + receiverAccount + " is not online. Message will be delivered when they are online.");
                }
            }
        }
    }
}

void ChatServer::onDisconnected()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket *>(sender());
    if (!clientSocket) return;

    QString disconnectedAccount;
    for (auto it = clients.begin(); it != clients.end(); ++it) {
        if (it.value() == clientSocket) {
            disconnectedAccount = it.key();
            clients.erase(it);
            break;
        }
    }

    qDebug() << "Client disconnected: " << disconnectedAccount;

    clientSocket->deleteLater();
    updateClientList();
}

void ChatServer::sendToClient(QTcpSocket *socket, const QString &message)
{
    if (socket && socket->state() == QTcpSocket::ConnectedState) {
        socket->write((message + "\n").toUtf8());
        socket->flush();
    }
}

void ChatServer::updateClientList()
{
    clientListWidget->clear();
    for (auto it = clients.constBegin(); it != clients.constEnd(); ++it) {
        clientListWidget->addItem(it.key());
    }
}

void ChatServer::startServer()
{
    if (!tcpServer->listen(QHostAddress::Any, 5678)) {
        qDebug() << "Server could not start!";
        statusLabel->setText("Server failed to start!");
        return;
    }

    statusLabel->setText("Server started on port 5678");
    startButton->setEnabled(false);
}
