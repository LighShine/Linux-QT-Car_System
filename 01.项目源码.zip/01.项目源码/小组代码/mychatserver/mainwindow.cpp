#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , server(new ChatServer(this))  // 初始化服务器
{
    ui->setupUi(this);

    // 连接按钮槽函数
    connect(ui->startButton, &QPushButton::clicked, this, &MainWindow::startServer);
    connect(ui->stopButton, &QPushButton::clicked, this, &MainWindow::stopServer);

    // 连接服务器信号到消息显示槽
    connect(server, &ChatServer::messageReceived, this, &MainWindow::displayMessage);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::startServer()
{
    if (!server->startServer(QHostAddress::Any, 1234)) {  // 启动服务器在端口1234
        displayMessage("服务器启动失败！");
    } else {
        displayMessage("服务器已启动，监听端口 1234...");
    }
}

void MainWindow::stopServer()
{
    server->close();
    displayMessage("服务器已停止。");
}

void MainWindow::displayMessage(const QString &message)
{
    ui->textEdit->append(message);  // 假设使用一个 QTextEdit 控件来显示消息
}
