#ifndef CHATSERVER_H
#define CHATSERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QMap>
#include <QWidget>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QListWidget>

class ChatServer : public QWidget
{
    Q_OBJECT

public:
    explicit ChatServer(QWidget *parent = nullptr);
    ~ChatServer();

protected:
    void incomingConnection(qintptr socketDescriptor);  // 处理新连接

private slots:
    void onReadyRead();  // 处理数据读取
    void onDisconnected();  // 处理断开连接
    void startServer();  // 启动服务器

private:
    QTcpServer *tcpServer;  // 用于监听的TCP服务器
    QMap<QString, QTcpSocket*> clients; // 保存所有已连接的客户端

    QLabel *statusLabel;  // 显示服务器状态的标签
    QListWidget *clientListWidget;  // 显示已连接客户端的列表
    QPushButton *startButton;  // 启动服务器的按钮

    QMap<QString, QList<QString>> offlineMessages; // 保存离线消息

    void sendToClient(QTcpSocket *socket, const QString &message);  // 发送消息给指定客户端
    void updateClientList();  // 更新客户端列表
};

#endif // CHATSERVER_H
