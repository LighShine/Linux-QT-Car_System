#ifndef VIDEOPLAYER_H
#define VIDEOPLAYER_H

#include <QVideoWidget>
#include <QMediaPlayer>

class VideoPlayer : public QVideoWidget
{
    Q_OBJECT

public:
    explicit VideoPlayer(QWidget *parent = nullptr);

    qint64 returnPosition();
    qint64 returnDuration();
    bool isPlaying();
    void playMusic(const QString &filePath);
    void resumeMusic();
    void pauseMusic();
    void setMusicProgress(int progressSliderValue);
    void setMusicForward();
    void setMusicBack();
    void setVolume(int volume);

signals:
    void calculateProgressSliderNumber(int);
    void playPosition(int);
    void playDuration(int);
    void positionChanged(qint64 position);  // 新增信号
    void durationChanged(qint64 duration);  // 新增信号

public slots:
    void setProgressSlider();

private slots:
    void handlePositionChanged(qint64 position);  // 私有槽函数
    void handleDurationChanged(qint64 duration);  // 私有槽函数

private:
    QMediaPlayer *thePlayer;
    QString currentPath;
};

#endif // VIDEOPLAYER_H
