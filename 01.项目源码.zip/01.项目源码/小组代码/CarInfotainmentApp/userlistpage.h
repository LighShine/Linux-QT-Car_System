#ifndef USERLISTPAGE_H
#define USERLISTPAGE_H

#include <QWidget>
#include <QListWidget>
#include <QSqlDatabase>
#include <QVBoxLayout>
#include <QPushButton>  // 添加
#include "mychatpage.h"  // 声明MyChatPage

class UserListPage : public QWidget
{
    Q_OBJECT

public:
    explicit UserListPage(QSqlDatabase &db, const QString &currentAccount, QWidget *parent = nullptr);
    ~UserListPage();

    MyChatPage* getCurrentChatPage() const;  // 声明返回当前聊天页面的方法

signals:
    void userClicked(const QString &username);
    void logout();  // 添加退出登录信号

private slots:
    void onUserClicked(QListWidgetItem *item);
    void handleLogout();  // 添加槽函数处理退出登录

private:
    void setupUI();
    void loadUserData();

    QSqlDatabase &db;
    QString currentAccount;
    QListWidget *userListWidget;
    QPushButton *logoutButton;  // 添加退出登录按钮
    MyChatPage *currentChatPage;  // 声明当前聊天页面指针
};

#endif // USERLISTPAGE_H
