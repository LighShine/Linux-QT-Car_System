#ifndef CHATMANAGER_H
#define CHATMANAGER_H

#include <QObject>
#include <QMap>
#include <QTcpSocket>
#include <QList>
#include "mychatpage.h"

class ChatManager : public QObject
{
    Q_OBJECT

public:
    static ChatManager* instance();  // 单例模式
    void initialize(QTcpSocket *socket);  // 初始化Socket连接
    void addChatPage(const QString &username, MyChatPage *chatPage);
    void removeChatPage(const QString &username);
    void sendMessage(const QString &recipient, const QString &message);
    void receiveMessage(const QString &sender, const QString &message);
    QList<QString> getCachedMessages(const QString &username); // 获取缓存消息

signals:
    void newMessageReceived(const QString &sender, const QString &message);

private slots:
    void onReadyRead();

private:
    explicit ChatManager(QObject *parent = nullptr);
    static ChatManager *m_instance;
    QTcpSocket *m_socket;
    QMap<QString, MyChatPage*> m_chatPages;  // 存储所有的聊天页面
    QMap<QString, QList<QString>> m_cachedMessages;  // 缓存未读消息
};

#endif // CHATMANAGER_H
