#include "weatherpage.h"
#include "ui_weatherpage.h"  // 确保包含此头文件来获取完整的类定义
#include <QIcon>
#include <QPalette>
#include <QPainter>
#include <QPushButton>

WeatherPage::WeatherPage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::WeatherPage)  // 使用完全定义的类
{
    ui->setupUi(this);  // 现在 setupUi 可以被正确识别
    setWindowTitle(tr("天气"));

    netThread = new NET_THREAD(this);
    timShowMessage = new QTimer(this);
    timShowMessage->start(2500);

    connect(netThread->weather, &WEATHER::signal_emit_weather_info, this, &WeatherPage::slot_get_weather_info);
    connect(ui->label_local_city, &DEFINE_QLABEL::mouse_clicked, this, &WeatherPage::slot_change_local_city);
    connect(timShowMessage, &QTimer::timeout, this, &WeatherPage::slot_show_message);

    netThread->startThread();
}

WeatherPage::~WeatherPage()
{
    delete ui;
    delete netThread;
    delete timShowMessage;
    if (dialog_change_city) delete dialog_change_city;
}

void WeatherPage::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    QPixmap pixmap(":/icons/back.png");
    QSize windowSize = this->size();
    QPixmap scaledPixmap = pixmap.scaled(windowSize, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
    painter.drawPixmap(0, 0, scaledPixmap);
    QWidget::paintEvent(event);
}

void WeatherPage::pushListWeak()
{
    // 添加具体的实现逻辑
    // 例如: showMessageList.append("weak label");
}

void WeatherPage::pushListDate()
{
    // 添加具体的实现逻辑
    // 例如: showMessageList.append("date label");
}

void WeatherPage::pushListWeatherType()
{
    // 添加具体的实现逻辑
    // 例如: showMessageList.append("weather type label");
}

void WeatherPage::slot_read_network_data(QNetworkReply *reply)
{
    QByteArray get_network = reply->readAll();
    qDebug() << "reply finished" << get_network;
}

void WeatherPage::slot_change_local_city()
{
    qDebug() << "clicked";

    if (dialog_change_city) {
        delete dialog_change_city;
    }
    dialog_change_city = new Dialog_Change_City(this);

    connect(dialog_change_city, SIGNAL(signal_emit_city_name(QString)), netThread->weather, SLOT(slot_change_local_city(QString)));
    connect(netThread->weather, SIGNAL(signal_emit_weather_info(WEATHER_INFO*)), this, SLOT(slot_get_weather_info(WEATHER_INFO*)));

    dialog_change_city->exec();
}

void WeatherPage::slot_get_weather_info(WEATHER_INFO *info)
{
    qDebug() << "get weather info";

    QString pixmap;

    showMessageList.clear();

    QString filePath1 = ":/icons/local.png";
    QIcon icon1(filePath1);
    QPixmap pixmap1 = icon1.pixmap(icon1.actualSize(QSize(64, 64)));
    ui->label_local_city->setPixmap(pixmap1);

    QString filePath2 = ":/refresh.png";
    QIcon icon2(filePath2);
    QPixmap pixmap2 = icon2.pixmap(icon2.actualSize(QSize(64, 64)));
    ui->label_refresh->setPixmap(pixmap2);

    ui->label_city_name->setText(info->cityName);
    ui->label_real_time_temp->setText(info->realTime.temp);
    ui->label_weather_type_1->setText(info->realTime.weatherType);

    showMessageList.append(tr("天气发布时间：") + info->realTime.updateTime);
    showMessageList.append("风向：" + info->realTime.windDirection + " " + info->realTime.windPower);
    showMessageList.append("湿度：" + info->realTime.humidity);

    if(info->realTime.weatherType.contains("多云"))
    {
        pixmap = ":/icons/duoyun.png";
    }
    else if(info->realTime.weatherType.contains("晴"))
    {
        pixmap = ":/icons/qing.png";
    }
    else if(info->realTime.weatherType.contains("小雨"))
    {
        pixmap = ":/icons/xiaoyu.png";
    }
    else if(info->realTime.weatherType.contains("暴雨"))
    {
        pixmap = ":/icons/baoyu.png";
    }
    else if(info->realTime.weatherType.contains("雪"))
    {
        pixmap = ":/icons/daxue.png";
    }
    else if(info->realTime.weatherType.contains("大雨"))
    {
        pixmap = ":/icons/dayu.png";
    }
    else if(info->realTime.weatherType.contains("雷雨"))
    {
        pixmap = ":/icons/leiyu.png";
    }

    ui->label_weather_icon->setPixmap(QPixmap(pixmap));
}

void WeatherPage::slot_show_message()
{
    static quint8 index = 0;

    if (showMessageList.isEmpty())
    {
        return;
    }

    ui->label_show_message->setText(showMessageList.at(index));

    index++;

    if (index >= showMessageList.size())
    {
        index = 0;
    }
}
