#ifndef CHATPAGE_H
#define CHATPAGE_H

#include <QWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QWebEngineView>
#include <QMediaPlayer>  // 用于音频播放

class ChatPage : public QWidget {
    Q_OBJECT

public:
    explicit ChatPage(QWidget *parent = nullptr);

signals:
    void goHome();  // 用于返回主页的信号

private slots:
    void sendMessage();     // 发送消息槽
    //void startVoiceInput(); // 开始语音输入槽

private:
    void initChatHistory();              // 初始化聊天历史
   // void playVoiceResponse(const QString &text); // 播放语音响应

    QTextEdit *chatHistory;     // 聊天历史框
    QLineEdit *inputField;      // 输入框
    QPushButton *sendButton;    // 发送按钮
    QPushButton *backButton;    // 返回按钮
    QPushButton *voiceButton;   // 语音输入按钮
    QWebEngineView *webView;    // 用于显示幽灵动画
    QMediaPlayer *player;       // 音频播放器
};

#endif // CHATPAGE_H
