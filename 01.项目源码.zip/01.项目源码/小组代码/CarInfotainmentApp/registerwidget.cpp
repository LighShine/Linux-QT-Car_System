include "registerwidget.h"

RegisterWidget::RegisterWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    QLineEdit *nameField = new QLineEdit(this);
    nameField->setPlaceholderText("Enter your full name");
    nameField->setStyleSheet("background-color: transparent; color: black; font-size: 14px; border: none; border-bottom: 1px solid #888; padding: 10px; margin-bottom: 20px;");

    QLineEdit *emailField = new QLineEdit(this);
    emailField->setPlaceholderText("Enter your email");
    emailField->setStyleSheet("background-color: transparent; color: black; font-size: 14px; border: none; border-bottom: 1px solid #888; padding: 10px; margin-bottom: 20px;");

    QLineEdit *passwordField = new QLineEdit(this);
    passwordField->setEchoMode(QLineEdit::Password);
    passwordField->setPlaceholderText("Enter your password");
    passwordField->setStyleSheet("background-color: transparent; color: black; font-size: 14px; border: none; border-bottom: 1px solid #888; padding: 10px; margin-bottom: 20px;");

    QCheckBox *termsCheckBox = new QCheckBox("I agree to the terms of service", this);
    termsCheckBox->setStyleSheet("color: #666; font-size: 12px;");

    QPushButton *registerButton = new QPushButton("REGISTER", this);
    registerButton->setStyleSheet("background-color: #3D85C6; color: white; padding: 10px; font-size: 14px; border-radius: 5px;");

    QPushButton *backButton = new QPushButton("BACK", this);
    backButton->setStyleSheet("background-color: #666; color: white; padding: 10px; font-size: 14px; border-radius: 5px; margin-top: 20px;");

    layout->addWidget(nameField);
    layout->addWidget(emailField);
    layout->addWidget(passwordField);
    layout->addWidget(termsCheckBox);
    layout->addWidget(registerButton);
    layout->addWidget(backButton);
    layout->setAlignment(Qt::AlignCenter);

    setLayout(layout);

    // 信号和槽连接
    connect(backButton, &QPushButton::clicked, this, &RegisterWidget::switchToLogin);
}

void RegisterWidget::onRegisterButtonClicked()
{
    // 注册逻辑处理
}
