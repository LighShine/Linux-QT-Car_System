#include "videoplayer.h"
#include <QMediaPlayer>
#include <QVideoWidget>

VideoPlayer::VideoPlayer(QWidget *parent) : QVideoWidget(parent)
{
    thePlayer = new QMediaPlayer(this);  // 确保父对象为VideoPlayer，这样可以自动管理内存
    thePlayer->setVideoOutput(this);  // 设置视频输出为当前的QVideoWidget

    // 连接 QMediaPlayer 信号到 VideoPlayer 信号
    connect(thePlayer, &QMediaPlayer::positionChanged, this, &VideoPlayer::handlePositionChanged);
    connect(thePlayer, &QMediaPlayer::durationChanged, this, &VideoPlayer::handleDurationChanged);
}

qint64 VideoPlayer::returnPosition()
{
    return thePlayer->position();
}

qint64 VideoPlayer::returnDuration()
{
    return thePlayer->duration();
}

void VideoPlayer::setProgressSlider()
{
    int sliderNumber = thePlayer->position() * 100 / thePlayer->duration();
    emit calculateProgressSliderNumber(sliderNumber);
    int musicPosition = thePlayer->position() / 1000;
    emit playPosition(musicPosition);
    int musicDuration = thePlayer->duration() / 1000;
    emit playDuration(musicDuration);
}

bool VideoPlayer::isPlaying()
{
    return (QMediaPlayer::PlayingState == thePlayer->state());
}

void VideoPlayer::playMusic(const QString &filePath)
{
    if (QMediaPlayer::PlayingState != thePlayer->state() && filePath != currentPath) {
        currentPath = filePath;
        thePlayer->setMedia(QUrl::fromLocalFile(currentPath));
    }
    thePlayer->play();
}

void VideoPlayer::resumeMusic()
{
    thePlayer->play();
}

void VideoPlayer::pauseMusic()
{
    if (QMediaPlayer::PlayingState == thePlayer->state()) {
        thePlayer->pause();
    }
}

void VideoPlayer::setMusicProgress(int progressSliderValue)
{
    thePlayer->setPosition(thePlayer->duration() * progressSliderValue / 100);
}

void VideoPlayer::setMusicForward()
{
    qint64 currentProgress = returnPosition() + 5000;
    thePlayer->setPosition(currentProgress);
}

void VideoPlayer::setMusicBack()
{
    qint64 currentProgress = returnPosition() - 5000;
    thePlayer->setPosition(currentProgress);
}

void VideoPlayer::setVolume(int volume)
{
    thePlayer->setVolume(volume);
}

void VideoPlayer::handlePositionChanged(qint64 position)
{
    emit positionChanged(position);  // 发射信号给外部使用
}

void VideoPlayer::handleDurationChanged(qint64 duration)
{
    emit durationChanged(duration);  // 发射信号给外部使用
}
