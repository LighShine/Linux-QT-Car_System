#ifndef LYRIC_H
#define LYRIC_H

#include <QWidget>
#include <QMainWindow>
#include <QFile>
#include <vector>
#include <QLabel>
#include <QObject>
#include <QTextStream>
#include <QRegularExpression>

class LyricLine {
public:
    qint64 time;
    QString text;
    LyricLine(qint64 time, QString text) : time(time), text(text) {}
};

bool operator<(const LyricLine &A, const LyricLine &B);

class Lyric {
    std::vector<LyricLine> lines; // Store all lyrics

public:
    explicit Lyric(QMainWindow *parent);
    ~Lyric();

    bool process(const QString &filePath); // Process lyrics file into LyricLine list
    int getIndex(qint64 position); // Get the lyric index based on time
    QString getLyricText(int index); // Get the lyric text based on index

private:
    QMainWindow *parentWindow; // Store parent MainWindow pointer
};

#endif // LYRIC_H
