#include "lyric.h"
#include <algorithm>

Lyric::Lyric(QMainWindow *parent) : parentWindow(parent) {}

Lyric::~Lyric() {}

bool operator<(const LyricLine &A, const LyricLine &B) {
    return A.time < B.time;
}

bool Lyric::process(const QString &lyricFilePath) {
    QFile lyricFile(lyricFilePath);
    if (!lyricFile.open(QFile::ReadOnly | QFile::Text)) {
        return false;
    }

    QTextStream in(&lyricFile);
    QString content = in.readAll();
    lyricFile.close();

    lines.clear();

    QRegularExpression rx("\\[(\\d+):(\\d+(\\.\\d+)?)\\]");
    QRegularExpressionMatchIterator it = rx.globalMatch(content);
    while (it.hasNext()) {
        QRegularExpressionMatch match = it.next();
        qint64 time = (match.captured(1).toInt() * 60 + match.captured(2).toDouble()) * 1000;
        int lastPos = match.capturedEnd();
        QString text = content.mid(lastPos, rx.match(content, lastPos).capturedStart() - lastPos).trimmed();
        lines.push_back(LyricLine(time, text));
    }

    std::sort(lines.begin(), lines.end());
    return !lines.empty();
}

int Lyric::getIndex(qint64 position) {
    if (lines.empty()) return -1;
    auto it = std::lower_bound(lines.begin(), lines.end(), LyricLine(position, ""), [](const LyricLine &a, const LyricLine &b) { return a.time < b.time; });
    if (it == lines.end()) return lines.size() - 1;
    return it - lines.begin();
}

QString Lyric::getLyricText(int index) {
    if (index < 0 || index >= lines.size()) return "";
    return lines[index].text;
}

