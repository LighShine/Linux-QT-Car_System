#ifndef SETTINGSPAGE_H
#define SETTINGSPAGE_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QSqlDatabase>
#include <QTcpSocket>
#include <QHostAddress>
#include "userlistpage.h"  // 声明UserListPage

class SettingsPage : public QWidget
{
    Q_OBJECT

public:
    explicit SettingsPage(QWidget *parent = nullptr);
    ~SettingsPage();

signals:
    void goHome();

private slots:
    void handleLogin();
    void showRegisterPage();
    void readServerResponse();

private:
    void setupUI();
    void setupDatabase();

    QLineEdit *accountField;
    QLineEdit *passwordField;
    QPushButton *loginButton;
    QPushButton *registerButton;
    QLabel *statusLabel;
    QLabel *imageLabel;
    QSqlDatabase db;
    QPushButton *backButton;
    QTcpSocket *tcpSocket;

    UserListPage *userListPage;  // 声明UserListPage指针
};

#endif // SETTINGSPAGE_H
