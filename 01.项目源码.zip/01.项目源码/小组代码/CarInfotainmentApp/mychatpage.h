#ifndef MYCHATPAGE_H
#define MYCHATPAGE_H

#include <QWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QTcpSocket>
#include <QListWidget>
#include <QSqlDatabase>

class MyChatPage : public QWidget
{
    Q_OBJECT

public:
    explicit MyChatPage(const QString &currentUser, const QString &targetUser, QSqlDatabase &db, QWidget *parent = nullptr);
    ~MyChatPage();
    void appendMessage(const QString &message, bool isSender);
    void loadChatHistory();
    void saveMessageToFile(const QString &message, bool isSender);


signals:
    void backToUserList();  // 新增返回用户列表的信号

private slots:
    void sendMessage();
    void readServerResponse();
    void goBack();  // 新增返回按钮槽函数

private:
    void setupUI();
    void setupSocket();
    QString getAvatarPath(const QString &username);  // 从数据库获取头像路径
    void updateLastMessage(const QString &user, const QString &message);  // 新增声明

    QString currentUser;
    QString targetUser;
    QTcpSocket *tcpSocket;
    QListWidget *chatArea;
    QLineEdit *inputField;
    QPushButton *sendButton;
    QSqlDatabase &db;  // 数据库引用，用于查询头像
};

#endif // MYCHATPAGE_H
