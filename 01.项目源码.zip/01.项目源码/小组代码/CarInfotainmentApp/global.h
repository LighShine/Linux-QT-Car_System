#ifndef GLOBAL_H
#define GLOBAL_H

#ifdef QT_NO_DEBUG
    #define dbg(str, param)
#else
    #define dbg(str, param)  qDebug()<<str<<param<<endl
#endif

/* 城市ID */
#define CITY_ID_BEIJING      "110000"       //北京
#define CITY_ID_BAOAN        "440306"       //深圳宝安区
#define CITY_ID_GUANGZHOU    "440100"       //广东省广州市

#define weather_api          "https://restapi.amap.com/v3/weather/weatherInfo?parameters"

#endif // GLOBAL_H

