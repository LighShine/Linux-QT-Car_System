#include "mychatpage.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QListWidgetItem>
#include <QLabel>
#include <QHostAddress>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QSqlQuery>
#include <QDateTime>

MyChatPage::MyChatPage(const QString &currentUser, const QString &targetUser, QSqlDatabase &db, QWidget *parent)
    : QWidget(parent), currentUser(currentUser), targetUser(targetUser), db(db)
{
    setupUI();
    setupSocket();
    loadChatHistory();  // 加载聊天记录
}

MyChatPage::~MyChatPage()
{
    tcpSocket->close();
    delete tcpSocket;
}

void MyChatPage::setupUI()
{
    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    // 顶部栏，包括返回按钮和对方用户名
    QHBoxLayout *topBarLayout = new QHBoxLayout();
    QPushButton *backButton = new QPushButton(this);
    backButton->setIcon(QIcon(":/icons/back.jpg"));  // 设置返回按钮图标
    backButton->setIconSize(QSize(35, 35));  // 增大图标大小
    backButton->setStyleSheet("background-color: transparent; border: none;");
    connect(backButton, &QPushButton::clicked, this, &MyChatPage::goBack);

    QLabel *titleLabel = new QLabel(targetUser, this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet(
        "font-size: 30px;"  // 增大字体
        "font-weight: bold;"  // 加粗字体
        "color: #2c3e50;"  // 使用深色字体
    );

    topBarLayout->addWidget(backButton);
    topBarLayout->addStretch();
    topBarLayout->addWidget(titleLabel);
    topBarLayout->addStretch();

    QWidget *topBarWidget = new QWidget(this);
    topBarWidget->setLayout(topBarLayout);
    topBarWidget->setStyleSheet(
        "background-color: rgba(255, 255, 255, 0.8);"  // 半透明背景
        "border-bottom: 1px solid #dcdcdc;"  // 底部边框
        "padding: 10px;"
    );

    mainLayout->addWidget(topBarWidget);

    // 聊天区域
    chatArea = new QListWidget(this);
    chatArea->setStyleSheet(
        "background-color: #F0F0F0;"
        "border: none;"
        "padding: 20px;"  // 增加内边距
    );
    mainLayout->addWidget(chatArea);

    // 输入和发送按钮
    QHBoxLayout *inputLayout = new QHBoxLayout();
    inputField = new QLineEdit(this);
    inputField->setPlaceholderText("Type your message...");
    inputField->setMinimumHeight(50);  // 增大输入框高度
    inputField->setStyleSheet(
        "font-size: 18px;"
        "padding: 10px;"
        "border: 2px solid #dcdcdc;"
        "border-radius: 20px;"
        "background-color: white;"
    );

    sendButton = new QPushButton("Send", this);
    sendButton->setMinimumSize(110, 50);  // 增大按钮尺寸
    sendButton->setStyleSheet(
        "font-size: 18px;"
        "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 #4CAF50, stop:1 #388E3C);"
        "color: white;"
        "border: none;"
        "border-radius: 20px;"
        "padding: 10px;"
        "font-weight: bold;"
    );

    inputLayout->addWidget(inputField);
    inputLayout->addWidget(sendButton);
    mainLayout->addLayout(inputLayout);

    setLayout(mainLayout);

    connect(sendButton, &QPushButton::clicked, this, &MyChatPage::sendMessage);
}
void MyChatPage::setupSocket()
{
    tcpSocket = new QTcpSocket(this);
    tcpSocket->connectToHost(QHostAddress("127.0.0.1"), 5678);

    if (tcpSocket->waitForConnected(3000)) {
        // 连接成功后不显示任何消息
        connect(tcpSocket, &QTcpSocket::readyRead, this, &MyChatPage::readServerResponse);
    } else {
        QMessageBox::warning(this, "Error", "Failed to connect to server.");
    }
}

void MyChatPage::loadChatHistory()
{
    QFile file(currentUser + "_" + targetUser + "_chat.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        while (!in.atEnd()) {
            QString line = in.readLine();

            // 判断这条消息是否是自己发送的
            bool isSender = line.startsWith("我: ");
            if (isSender) {
                line.remove(0, 3); // 移除"我: "前缀
            } else if (line.startsWith(targetUser + ": ")) {
                line.remove(0, targetUser.length() + 2); // 移除"对方: "前缀
            }

            // 显示消息
            appendMessage(line, isSender);
        }
        file.close();
    }
}

void MyChatPage::sendMessage()
{
    QString message = inputField->text();
    if (!message.isEmpty()) {
        QString fullMessage = currentUser + ":" + targetUser + ":" + message;
        tcpSocket->write(fullMessage.toUtf8() + "\n");
        appendMessage(message, true);  // 发送自己的消息

        saveMessageToFile(message, true);  // 保存消息到文件
        updateLastMessage(currentUser, message); // 更新最后消息
        inputField->clear();
    }
}

void MyChatPage::saveMessageToFile(const QString &message, bool isSender)
{
    QFile file(currentUser + "_" + targetUser + "_chat.txt");
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);

        if (isSender) {
            out << "我: " << message << "\n";
        } else {
            out << targetUser << ": " << message << "\n";
        }

        file.close();
    }
}



void MyChatPage::readServerResponse()
{
    while (tcpSocket->canReadLine()) {
        QString response = QString::fromUtf8(tcpSocket->readLine()).trimmed();
        appendMessage(response, false);  // 假设接收到的消息是来自对方的

        saveMessageToFile(response, false);  // 保存消息到文件
        updateLastMessage(targetUser, response); // 更新最后消息
    }
}

void MyChatPage::appendMessage(const QString &message, bool isSender)
{
    QListWidgetItem *item = new QListWidgetItem(chatArea);
    QWidget *messageWidget = new QWidget();
    QHBoxLayout *messageLayout = new QHBoxLayout(messageWidget);

    QLabel *avatarLabel = new QLabel(messageWidget);
    avatarLabel->setFixedSize(60, 60);  // 更大的圆形头像
    avatarLabel->setStyleSheet("border-radius: 30px;");

    QLabel *messageLabel = new QLabel(messageWidget);
    messageLabel->setText(message);
    messageLabel->setWordWrap(true);
    messageLabel->setStyleSheet(
        "border-radius: 15px;"
        "padding: 20px;"
        "font-size: 18px;"
        "border: 1px solid #dcdcdc;"
        "background-color: #ffffff;"
        "box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);"
    );

    QString avatarPath;

    if (isSender) {
        avatarPath = getAvatarPath(currentUser);
        avatarLabel->setPixmap(QPixmap(avatarPath).scaled(60, 60, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        messageLabel->setStyleSheet(
            "background-color: rgba(255, 255, 224, 0.9);"  // 浅黄色背景，增加透明度
            "color: #333;"
            "border-radius: 15px;"
            "padding: 20px;"
            "font-size: 18px;"
            "border: none;"
            "box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);"
        );
        messageLayout->addStretch();
        messageLayout->addWidget(messageLabel);
        messageLayout->addWidget(avatarLabel);
    } else {
        avatarPath = getAvatarPath(targetUser);
        avatarLabel->setPixmap(QPixmap(avatarPath).scaled(60, 60, Qt::KeepAspectRatio, Qt::SmoothTransformation));
        messageLayout->addWidget(avatarLabel);
        messageLayout->addWidget(messageLabel);
        messageLayout->addStretch();
    }

    messageWidget->setLayout(messageLayout);
    item->setSizeHint(messageWidget->sizeHint());
    chatArea->setItemWidget(item, messageWidget);
    chatArea->scrollToBottom();
}

QString MyChatPage::getAvatarPath(const QString &username)
{
    QSqlQuery query(db);
    query.prepare("SELECT avatar FROM users WHERE username = :username");
    query.bindValue(":username", username);
    if (query.exec() && query.next()) {
        return query.value(0).toString();
    }
    return ":/path/to/default_avatar.png";  // 使用默认头像
}

void MyChatPage::goBack()
{
    emit backToUserList();  // 发射返回信号
    this->hide();  // 关闭当前聊天窗口
}
void MyChatPage::updateLastMessage(const QString &user, const QString &message)
{
    QFile file(user + "_last_message.txt");
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        out << message << "|" << QDateTime::currentDateTime().toString();
        file.close();
    }
}
