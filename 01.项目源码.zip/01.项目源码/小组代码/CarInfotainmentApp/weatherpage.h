#ifndef WEATHERPAGE_H
#define WEATHERPAGE_H

#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonParseError>
#include <QJsonObject>
#include <QLabel>
#include <QTimer>
#include <QTime>
#include <QUrl>
#include <QDebug>
#include <global.h>
#include <net_thread.h>
#include <dialog_change_city.h>
#include "define_qlabel.h"

QT_BEGIN_NAMESPACE
namespace Ui { class WeatherPage; }
QT_END_NAMESPACE

class WeatherPage : public QWidget
{
    Q_OBJECT

public:
    explicit WeatherPage(QWidget *parent = nullptr);
    ~WeatherPage();

    /* 插入weak label */
    void pushListWeak();
    void pushListDate();
    void pushListWeatherType();

    void paintEvent(QPaintEvent *event) override;

private slots:
    void slot_read_network_data(QNetworkReply *reply);
    void slot_get_weather_info(WEATHER_INFO *info);
    void slot_change_local_city();
    void slot_show_message();

private:
    Ui::WeatherPage *ui;
    QStringList showMessageList;
    QTimer *timShowMessage = nullptr;
    NET_THREAD *netThread = nullptr;
    Dialog_Change_City *dialog_change_city = nullptr;
};

#endif // WEATHERPAGE_H
