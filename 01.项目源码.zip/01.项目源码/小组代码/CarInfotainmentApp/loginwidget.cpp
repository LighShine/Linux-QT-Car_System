#include "loginwidget.h"

LoginWidget::LoginWidget(QWidget *parent) : QWidget(parent)
{
    QVBoxLayout *layout = new QVBoxLayout(this);

    QLineEdit *emailField = new QLineEdit(this);
    emailField->setPlaceholderText("E-mail");
    emailField->setStyleSheet("background-color: transparent; color: white; font-size: 14px; border: none; border-bottom: 1px solid #888; padding: 10px; margin-bottom: 20px;");

    QLineEdit *passwordField = new QLineEdit(this);
    passwordField->setPlaceholderText("Password");
    passwordField->setEchoMode(QLineEdit::Password);
    passwordField->setStyleSheet("background-color: transparent; color: white; font-size: 14px; border: none; border-bottom: 1px solid #888; padding: 10px; margin-bottom: 20px;");

    QPushButton *loginButton = new QPushButton("LOG IN", this);
    loginButton->setStyleSheet("background-color: #3D85C6; color: white; padding: 10px; font-size: 14px; border-radius: 5px; margin-bottom: 10px;");

    QPushButton *registerButton = new QPushButton("SIGN UP", this);
    registerButton->setStyleSheet("background-color: #66A2CC; color: white; padding: 10px; font-size: 14px; border-radius: 5px;");

    QLabel *helpLabel = new QLabel("HELP", this);
    helpLabel->setStyleSheet("color: white; font-size: 12px;");
    helpLabel->setAlignment(Qt::AlignCenter);

    layout->addWidget(emailField);
    layout->addWidget(passwordField);
    layout->addWidget(loginButton);
    layout->addWidget(registerButton);
    layout->addWidget(helpLabel);
    layout->setAlignment(Qt::AlignCenter);

    setLayout(layout);

    // 信号和槽连接
    connect(registerButton, &QPushButton::clicked, this, &LoginWidget::switchToRegister);
}

void LoginWidget::onLoginButtonClicked()
{
    // 登录逻辑处理
}
