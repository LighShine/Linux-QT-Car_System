#ifndef MUSICPAGE_H
#define MUSICPAGE_H

#include <QWidget>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFileDialog>
#include <QListWidget>
#include <QMap>
#include <QTimer>
#include <QTextBrowser>
#include <QCheckBox>

class MusicPage : public QWidget
{
    Q_OBJECT

public:
    explicit MusicPage(QWidget *parent = nullptr);
    ~MusicPage();

signals:
    void goHome();  // 返回主页的信号

private slots:
    void playMusic();
    void pauseMusic();
    void stopMusic();
    void openFile();
    void nextTrack();
    void previousTrack();
    void changeVolume(int volume);
    void updatePosition(qint64 position);
    void setPosition(int position);
    void updateDuration(qint64 duration);
    void updateLyrics();
    void loadMusicFile(const QString &filePath);
    void toggleFavorite();
    void savePlaylist();
    void loadPlaylist();

private:
    QMediaPlayer *player;
    QMediaPlaylist *playlist;
    QPushButton *playButton;
    QPushButton *pauseButton;
    QPushButton *stopButton;
    QPushButton *openButton;
    QPushButton *nextButton;
    QPushButton *prevButton;
    QPushButton *favoriteButton;
    QPushButton *saveButton;
    QPushButton *loadButton;
    QSlider *positionSlider;
    QSlider *volumeSlider;
    QLabel *durationLabel;
    QTextBrowser *lyricsBrowser;
    QListWidget *playlistWidget;
    QMap<QString, QString> lyricsMap;  // 存储歌词的映射
    QTimer *lyricsTimer;
    QString currentTrack;
    QList<QString> favoriteSongs;  // 存储收藏的歌曲

    void setupUI();
    void loadLyrics(const QString &filePath);
    void loadCoverArt(const QString &filePath);
    QString formatTime(qint64 time);
};

#endif // MUSICPAGE_H
