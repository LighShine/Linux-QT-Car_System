#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include <QObject>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QString>
#include <QDebug>
#include <QFile>

class MediaPlayer : public QObject {
    Q_OBJECT
public:
    explicit MediaPlayer(QObject *parent = nullptr);
void play();
    void playMusic(const QString &filePath);
    void pauseMusic();
    void setMusicProgress(int progressSliderValue);
    void setMusicVolume(int volume);
    bool isPlaying();
    qint64 returnPosition();
    qint64 returnDuration();
    void endMusic();
    void setPlaylist(QMediaPlaylist *playlist); // New method to set playlist

public slots:
    void handleError(QMediaPlayer::Error error);
    void setProgressSlider();
    void checkIfEnd();

signals:
    void calculateProgressSliderNumber(int number);
    void playPosition(int musicPosition);
    void playDuration(int musicDuration);
    void musicEnded();

private:
    QMediaPlayer *mediaPlayer;
    QMediaPlaylist *playlist; // New member for playlist
};

#endif // MEDIAPLAYER_H
