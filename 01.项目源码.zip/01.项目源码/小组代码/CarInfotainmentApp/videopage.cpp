#include "videopage.h"
#include <QFileDialog>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QDebug>

VideoPage::VideoPage(QWidget *parent)
    : QWidget(parent), isFullScreen(false)
{
    setFixedSize(1280, 720);  // 设置页面大小

    videoPlayer = new VideoPlayer(this);

    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(videoPlayer);

    // 创建控件
    addFileBtn = new QPushButton("📂 打开", this);
    pauseBtn = new QPushButton("⏯ 播放/暂停", this);
    stopBtn = new QPushButton("⏹ 重置", this);
    fullScreenBtn = new QPushButton("⛶ 全屏", this);
    backBtn = new QPushButton("返回", this);  // 创建返回按钮
    progressSlider = new QSlider(Qt::Horizontal, this);
    volumeSlider = new QSlider(Qt::Horizontal, this);
    timeLabel = new QLabel("00:00 / 00:00", this);

    // 初始化音量滑块和进度条
    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(50);
    progressSlider->setRange(0, 100);  // 假设进度条的范围也是0-100

    // 设置样式
    addFileBtn->setStyleSheet("QPushButton { font-size: 16px; padding: 8px; }");
    pauseBtn->setStyleSheet("QPushButton { font-size: 16px; padding: 8px; }");
    stopBtn->setStyleSheet("QPushButton { font-size: 16px; padding: 8px; }");
    fullScreenBtn->setStyleSheet("QPushButton { font-size: 16px; padding: 8px; }");
    backBtn->setStyleSheet("QPushButton { font-size: 16px; padding: 8px; }");
    progressSlider->setStyleSheet("QSlider::handle:horizontal { background: #5c5c5c; width: 10px; }");
    volumeSlider->setStyleSheet("QSlider::handle:horizontal { background: #5c5c5c; width: 10px; }");
    timeLabel->setStyleSheet("QLabel { font-size: 16px; }");

    // 设置控件的固定宽度
    progressSlider->setFixedWidth(200);
    volumeSlider->setFixedWidth(100);

    // 设置控件布局
    QHBoxLayout *controlLayout = new QHBoxLayout;
    controlLayout->setSpacing(10);
    controlLayout->addWidget(addFileBtn);
    controlLayout->addWidget(pauseBtn);
    controlLayout->addWidget(stopBtn);
    controlLayout->addWidget(fullScreenBtn);
    controlLayout->addWidget(progressSlider);
    controlLayout->addWidget(timeLabel);
    controlLayout->addWidget(volumeSlider);
    controlLayout->addWidget(backBtn);  // 将返回按钮添加到布局中

    mainLayout->addLayout(controlLayout);

    // 连接信号和槽
    connect(addFileBtn, &QPushButton::clicked, this, &VideoPage::onAddFileBtnClicked);
    connect(pauseBtn, &QPushButton::clicked, this, &VideoPage::onPauseBtnClicked);
    connect(stopBtn, &QPushButton::clicked, this, &VideoPage::onStopBtnClicked);
    connect(fullScreenBtn, &QPushButton::clicked, this, &VideoPage::onFullScreenBtnClicked);
    connect(progressSlider, &QSlider::valueChanged, this, &VideoPage::onProgressSliderMoved);  // 改为使用valueChanged(int)
    connect(volumeSlider, &QSlider::valueChanged, this, &VideoPage::onVolumeSliderChanged);
    connect(videoPlayer, &VideoPlayer::positionChanged, this, &VideoPage::updateProgressSlider);
    connect(videoPlayer, &VideoPlayer::durationChanged, this, &VideoPage::setProgressSlider);
    connect(backBtn, &QPushButton::clicked, this, &VideoPage::goHome);  // 连接返回按钮的点击信号到goHome信号
}

void VideoPage::onAddFileBtnClicked()
{
    QFileDialog fileDialog(this, tr("Open Video File"), QString(), tr("Video Files (*.mp4)"));
    fileDialog.setOption(QFileDialog::DontUseNativeDialog); // 禁用原生文件对话框
    if (fileDialog.exec() == QDialog::Accepted) {
        QString filename = fileDialog.selectedFiles().first();
        if (!filename.isEmpty()) {
            videoPlayer->playMusic(filename);
        }
    }
}

void VideoPage::onPauseBtnClicked()
{
    if (videoPlayer->isPlaying()) {
        videoPlayer->pauseMusic();
    } else {
        videoPlayer->resumeMusic();
    }
}

void VideoPage::onStopBtnClicked()
{
    videoPlayer->pauseMusic();
    videoPlayer->setMusicProgress(0);
    progressSlider->setValue(0);
    timeLabel->setText("00:00 / 00:00");
}

void VideoPage::onFullScreenBtnClicked()
{
    if (isFullScreen) {
        window()->showNormal();
        isFullScreen = false;
        fullScreenBtn->setText("⛶ 全屏");
    } else {
        window()->showFullScreen();
        isFullScreen = true;
        fullScreenBtn->setText("⛶ 退出全屏");
    }
}

void VideoPage::onProgressSliderMoved(int position)
{
    videoPlayer->setMusicProgress(position);
}

void VideoPage::onVolumeSliderChanged(int value)
{
    videoPlayer->setVolume(value);
}

void VideoPage::updateProgressSlider()
{
    qint64 position = videoPlayer->returnPosition();
    qint64 duration = videoPlayer->returnDuration();

    progressSlider->setValue(position);
    progressSlider->setMaximum(duration);  // 设置进度条的最大值为视频总时长
    timeLabel->setText(QString("%1 / %2").arg(formatTime(position)).arg(formatTime(duration)));
}

void VideoPage::setProgressSlider(int value)
{
    progressSlider->setValue(value);
}

QString VideoPage::formatTime(qint64 time)
{
    int secs = time / 1000;
    int mins = secs / 60;
    secs %= 60;
    return QString("%1:%2")
        .arg(mins, 2, 10, QLatin1Char('0'))
        .arg(secs, 2, 10, QLatin1Char('0'));
}
