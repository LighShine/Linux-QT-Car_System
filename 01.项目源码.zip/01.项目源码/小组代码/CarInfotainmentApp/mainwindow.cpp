#include "mainwindow.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPixmap>
#include <QMovie>
#include <QTimer>
#include <QDateTime>
#include <QAudioInput>
#include <QBuffer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonArray>
#include <QPropertyAnimation>
#include <QWebEngineView>  // 引入 QWebEngineView
#include <QSoundEffect>
#include "audioplayer.h" // 假设 AudioPlayer 类的定义在 audioplayer.h 中
#include <QThread>
#include "weatherpage.h"  // 添加此行，确保 WeatherPage 类的定义被包含

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , stackedWidget(new QStackedWidget(this))
    , player(new QMediaPlayer(this))
    , audioInput(nullptr)
    , audioBuffer(nullptr)
    , networkManager(new QNetworkAccessManager(this))
{
    setFixedSize(1280, 720); // 设置固定窗口大小

    setupUI();
    setupAudioInput();
    listenForKeyword();

    setCentralWidget(stackedWidget);
    stackedWidget->setCurrentWidget(homePage);
}

MainWindow::~MainWindow()
{
    if (audioInput) {
        audioInput->stop();
        delete audioInput;
    }
    if (audioBuffer) {
        delete audioBuffer;
    }
    delete player;
    delete networkManager;
}

void MainWindow::setupUI()
{
    // 创建主页
    homePage = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(homePage);
    mainLayout->setContentsMargins(0, 0, 0, 0); // 设置主布局边距

    // 设置主页背景为渐变颜色，并增加透明度效果
        homePage->setStyleSheet(
            "background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
            "stop:0 rgba(54, 100, 139, 0.9), stop:1 rgba(255, 255, 255, 0.6));"
            "border: 0px;"
        );

    // 初始化 QWebEngineView 用于显示小幽灵动画
    webView = new QWebEngineView(this);
    webView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed); // 使宽度适应窗口
    webView->setFixedHeight(150); // 设置幽灵动画的最大高度
    QUrl url("qrc:/html/ghost.html");
    webView->setUrl(url); // 使用资源文件中的 HTML

    // 使用 QMovie 创建动态 GIF
    centerLabel = new ClickableLabel(homePage);
    QMovie *movie = new QMovie(":/images/movedcircle.gif"); // 使用GIF文件路径
    movie->setScaledSize(QSize(830, 830));  // 确保GIF大小与centerLabel一致
    centerLabel->setMovie(movie);
    movie->start(); // 启动动画

    // 设置GIF动画背景为透明并居中显示
    centerLabel->setFixedSize(400, 400); // 设置固定大小，与GIF大小一致
    centerLabel->setAlignment(Qt::AlignCenter); // 居中对齐GIF
    centerLabel->setStyleSheet(
        "background-color: black; " // 设置背景为黑色
        "border-radius: 200px; "    // 圆角半径应为宽度的一半
        "border: 0px solid rgba(255, 255, 255, 0); " // 设置边框为透明
        "box-shadow: 0px 0px 20px 5px rgba(255, 255, 255, 0.5);" // 添加阴影
    );
    // 底部时间标签
    timeLabel = new QLabel(homePage);
    timeLabel->setStyleSheet("font-size: 22px; color: #FFFFFF; background-color: #4a4a4a; padding: 10px; border-radius: 5px; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;");
    timeLabel->setAlignment(Qt::AlignCenter);
    timeLabel->setFixedHeight(100); // 设置较小的时间标签高度

    // 左侧按钮布局
    QVBoxLayout *leftLayout = new QVBoxLayout;
    leftLayout->setSpacing(20);
    leftLayout->setContentsMargins(20, 20, 20, 20);

    musicButton = createButton(":/icons/music_main.png", "音乐"); // 音乐按钮
    navButton = createButton(":/icons/ditu_main.png", "地图"); // 地图按钮
    videoButton = createButton(":/icons/icon_video.png", "视频"); // 视频按钮
    leftLayout->addWidget(musicButton);
    leftLayout->addWidget(navButton);
    leftLayout->addWidget(videoButton);

    // 右侧按钮布局
    QVBoxLayout *rightLayout = new QVBoxLayout;
    rightLayout->setSpacing(20);
    rightLayout->setContentsMargins(20, 20, 20, 20);

    weatherButton = createButton(":/icons/icon_weather.png", "天气"); // 天气按钮
    chatButton = createButton(":/icons/ic_xiaozhi.png", "小治助手"); // 小治助手按钮
    settingsButton = createButton(":/icons/icon_chat.png", "聊天"); // 聊天按钮
    rightLayout->addWidget(weatherButton);
    rightLayout->addWidget(chatButton);
    rightLayout->addWidget(settingsButton);

    // 主体布局
    QHBoxLayout *bodyLayout = new QHBoxLayout;
    bodyLayout->addLayout(leftLayout);
    bodyLayout->addWidget(centerLabel, 0, Qt::AlignCenter);
    bodyLayout->addLayout(rightLayout);

    // 添加到主布局
    mainLayout->addWidget(webView, 0, Qt::AlignTop);  // 添加幽灵动画在最顶端，并居上
    mainLayout->addStretch();  // 添加一个伸缩区域来占据多余空间
    mainLayout->addLayout(bodyLayout);
    mainLayout->addStretch();  // 添加一个伸缩区域来占据多余空间
    mainLayout->addWidget(timeLabel, 0, Qt::AlignBottom); // 添加时间标签在底部

    // 更新时间
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, [this]() {
        timeLabel->setText(QDateTime::currentDateTime().toString("yyyy年MM月dd日<br> dddd hh:mm AP"));
    });
    timer->start(1000);

    stackedWidget->addWidget(homePage);

    // 保持原有按钮连接和功能不变
    connect(navButton, &QPushButton::clicked, this, &MainWindow::showNavigationPage);
    connect(videoButton, &QPushButton::clicked, this, &MainWindow::showVideoPage);
    connect(musicButton, &QPushButton::clicked, this, &MainWindow::showMusicPage);
    connect(weatherButton, &QPushButton::clicked, this, &MainWindow::showWeatherPage);
    connect(chatButton, &QPushButton::clicked, this, &MainWindow::showChatPage);
    connect(settingsButton, &QPushButton::clicked, this, &MainWindow::showSettingsPage);
}



QPushButton* MainWindow::createButton(const QString &iconPath, const QString &text) {
    QPushButton *button = new QPushButton;
    button->setIcon(QIcon(iconPath));
    button->setIconSize(QSize(40, 40));
    button->setText(text);
    button->setStyleSheet(
        "font-size: 18px; color: #FFFFFF; "
        "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 #48C6EF, stop:1 #6F86D6);"
        "border: 2px solid #FFFFFF; border-radius: 25px; padding: 12px; "
        "box-shadow: 2px 4px 10px rgba(0, 0, 0, 0.2);"
    );
    button->setFixedSize(220, 75);
    return button;
}

void MainWindow::setupAnimations()
{
    QPropertyAnimation *anim = new QPropertyAnimation(centerLabel, "geometry");
    anim->setDuration(1000);
    anim->setStartValue(QRect(centerLabel->x(), centerLabel->y(), 0, 0));
    anim->setEndValue(QRect(centerLabel->x(), centerLabel->y(), 350, 350)); // 调整动画尺寸
    anim->setEasingCurve(QEasingCurve::OutBounce);
    anim->start();
}

void MainWindow::setupAudioInput()
{
    audioBuffer = new QBuffer(this);
    audioBuffer->open(QIODevice::ReadWrite);

    QAudioFormat format;
    format.setSampleRate(16000);
    format.setChannelCount(1);
    format.setSampleSize(16);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);

    audioInput = new QAudioInput(format, this);
    audioInput->start(audioBuffer);
}

void MainWindow::listenForKeyword()
{
    QTimer *listenTimer = new QTimer(this);
    connect(listenTimer, &QTimer::timeout, this, &MainWindow::processVoiceCommand);
    listenTimer->start(5000);
}

void MainWindow::processVoiceCommand()
{
    if (audioInput) {
        audioInput->stop(); // 暂停音频输入以清空缓冲区
    }

    QByteArray audioData = audioBuffer->data();
    if (audioData.isEmpty()) {
        qDebug() << "No audio data captured.";
        if (audioInput) {
            audioInput->start(audioBuffer); // 重启音频输入
        }
        return;
    }

    QNetworkRequest request(QUrl("https://vop.baidu.com/server_api"));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "audio/pcm;rate=16000");

    QJsonObject json;
    json["format"] = "pcm";
    json["rate"] = 16000;
    json["channel"] = 1;
    json["token"] = "24.8ba19ac78e9f633c73fa694ba4b37b4e.2592000.1727012213.282335-109777799";
    json["cuid"] = "1234567JAVA";
    json["speech"] = QString(audioData.toBase64());
    json["len"] = audioData.size();

    QNetworkReply *reply = networkManager->post(request, QJsonDocument(json).toJson());
    connect(reply, &QNetworkReply::finished, this, &MainWindow::handleVoiceRecognitionResult);

    audioBuffer->buffer().clear();
    audioBuffer->seek(0);

    if (audioInput) {
        audioInput->start(audioBuffer); // 重启音频输入
    }
}

void MainWindow::handleVoiceRecognitionResult()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply *>(sender());
    if (reply->error() == QNetworkReply::NoError) {
        QByteArray response_data = reply->readAll();
        QJsonDocument jsonResponse = QJsonDocument::fromJson(response_data);
        QJsonObject jsonObject = jsonResponse.object();

        QJsonArray resultArray = jsonObject["result"].toArray();
        if (!resultArray.isEmpty()) {
            QString recognizedText = resultArray.at(0).toString();
            qDebug() << "Recognized text:" << recognizedText;

            QString cleanText = recognizedText.simplified().remove(QRegExp("[,，。！？]"));
            qDebug() << "Clean text:" << cleanText;

            // 简化正则表达式，增加灵活性
            if (cleanText.contains(QRegExp("小[志治智]你好"))) {
                playVoiceMessagehello();
            } else if (cleanText.contains(QRegExp("小[志治智].*(听音乐|播放音乐|音乐)"))) {
                playVoiceMessagemusic();
                showMusicPage();
            } else if (cleanText.contains(QRegExp("小[志治智].*(看视频|播放视频|视频)"))) {
                playVoiceMessagevideo();
                showVideoPage();
            } else if (cleanText.contains(QRegExp("小[志治智].*(查看天气|天气|天气预报)"))) {
                playVoiceMessageweather();
                showWeatherPage();
            } else if (cleanText.contains(QRegExp("小[志治智].*(导航|地图)"))) {
                playVoiceMessageditu();
                showNavigationPage();
            } else if (cleanText.contains(QRegExp("小[志治智].*(聊天|对话)"))) {
                playVoiceMessagechat();
                showSettingsPage();
            } else if (cleanText.contains(QRegExp("(Hi|Hello|Hey|嗨).*小[志治智]"))) { // 简化正则表达式
                playVoiceMessagexiaozhi();
                showChatPage();
            } else {
                qDebug() << "Unrecognized command.";
            }
        }
    } else {
        qDebug() << "Error in network reply:" << reply->errorString();
    }

    audioBuffer->buffer().clear();
    audioBuffer->seek(0);

    reply->deleteLater();
}

void MainWindow::showVideoPage()
{
    VideoPage *videoPage = new VideoPage();
    connect(videoPage, &VideoPage::goHome, this, &MainWindow::goHome);
    stackedWidget->addWidget(videoPage);
    stackedWidget->setCurrentWidget(videoPage);
}


void MainWindow::showMusicPage()
{
    MusicPage *musicPage = new MusicPage();
    connect(musicPage, &MusicPage::goHome, this, &MainWindow::goHome);
    stackedWidget->addWidget(musicPage);
    stackedWidget->setCurrentWidget(musicPage);
}

void MainWindow::showNavigationPage()
{
    NavigationPage *navigationPage = new NavigationPage();
    connect(navigationPage, &NavigationPage::goHome, this, &MainWindow::goHome);
    stackedWidget->addWidget(navigationPage);
    stackedWidget->setCurrentWidget(navigationPage);
}

void MainWindow::showWeatherPage()
{
    WeatherPage *weatherPage = new WeatherPage(this);  // 确保这个类的定义已包含
    stackedWidget->addWidget(weatherPage);
    stackedWidget->setCurrentWidget(weatherPage);
}


void MainWindow::showChatPage()
{
    ChatPage *chatPage = new ChatPage();
    connect(chatPage, &ChatPage::goHome, this, &MainWindow::goHome);
    stackedWidget->addWidget(chatPage);
    stackedWidget->setCurrentWidget(chatPage);
}

void MainWindow::showSettingsPage()
{
    SettingsPage *settingsPage = new SettingsPage();
    connect(settingsPage, &SettingsPage::goHome, this, &MainWindow::goHome);
    stackedWidget->addWidget(settingsPage);
    stackedWidget->setCurrentWidget(settingsPage);
}

void MainWindow::goHome()
{
    stackedWidget->setCurrentWidget(homePage);
}

void MainWindow::playVoiceMessagehello()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_hello.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}

void MainWindow::playVoiceMessagechat()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_chat.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}

void MainWindow::playVoiceMessageditu()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_ditu.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}

void MainWindow::playVoiceMessagemusic()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_music.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}

void MainWindow::playVoiceMessagevideo()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_video.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}

void MainWindow::playVoiceMessageweather()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_weather.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}

void MainWindow::playVoiceMessagexiaozhi()
{
    QThread *audioThread = new QThread;
       AudioPlayer *audioPlayer = new AudioPlayer();

       // 将 AudioPlayer 移动到新的线程
       audioPlayer->moveToThread(audioThread);

       // 连接信号和槽
       connect(audioThread, &QThread::started, [audioPlayer]() {
           audioPlayer->playAudio("qrc:/audio/voice_xiaozhi.mp3");
       });

       connect(audioPlayer, &AudioPlayer::finished, audioThread, &QThread::quit);
       connect(audioPlayer, &AudioPlayer::finished, audioPlayer, &AudioPlayer::deleteLater);
       connect(audioThread, &QThread::finished, audioThread, &QThread::deleteLater);

       // 启动线程
       audioThread->start();
}
