#include "dialog_change_city.h"
#include "ui_dialog_change_city.h"

#include <QFile>
#include <QDir>

Dialog_Change_City::Dialog_Change_City(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_Change_City)
{
    ui->setupUi(this);
    ui->comboBox->setEditable(true); // 设置为可编辑模式

    // 加载所有城市到 comboBox
    loadAllCities();
}
Dialog_Change_City::~Dialog_Change_City()
{
    delete ui;
}

void Dialog_Change_City::loadAllCities()
{
    QJsonParseError error;
    QByteArray jsonData;
    QJsonArray jsonArray;

    QString filePath = tr(":/new/prefix1/city.json");
    QFile jsonFile(filePath);

    if (!jsonFile.open(QIODevice::ReadOnly)) {
        qDebug() << "Cannot open JSON file";
        return;
    }

    jsonData = jsonFile.readAll();
    jsonFile.close();

    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData, &error);

    if (error.error != QJsonParseError::NoError) {
        qDebug() << "JSON parse error";
        return;
    }

    jsonArray = jsonDoc.array();

    // 将所有城市添加到 comboBox 中
    for (int i = 0; i < jsonArray.size(); ++i) {
        QJsonObject cityObj = jsonArray.at(i).toObject();
        QString cityName = cityObj.value("中文名").toString();
        ui->comboBox->addItem(cityName);
    }

    // 默认显示第一个城市（如果有）
    if (ui->comboBox->count() > 0) {
        ui->comboBox->setCurrentIndex(0);
    }
}

void Dialog_Change_City::on_comboBox_currentTextChanged(const QString &arg1)
{
    dbg("get text changed",0);

    //4.edition
    if(arg1.isEmpty())
    {
        ui->comboBox->clear();  // 清空现有选项
    }

    QJsonParseError error;
    QByteArray jsonDate;
    QJsonArray jsonArray;

    QString filePath = tr(":/new/prefix1/city.json");

    QFile jsonFile(filePath);

    if (!jsonFile.open(QIODevice::ReadOnly)) {
        dbg("Cannot open JSON file", 0);
        return;
    }

    jsonDate = jsonFile.readAll();
    jsonFile.close();

    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonDate, &error);

    if(error.error != QJsonParseError::NoError)
    {
        dbg("json read error", 0);
        return;
    }

    jsonArray = jsonDoc.array();

    // 清空现有选项
    //ui->comboBox->clear();

    // 遍历 JSON 数组，找到匹配的城市
    for(int i = 0; i < jsonArray.size(); i++)
    {
        QJsonObject cityObj = jsonArray.at(i).toObject();
        QString cityName = cityObj.value("中文名").toString();

        // 如果城市名称包含输入内容，则添加到 comboBox 中
        if(cityName.contains(arg1))
        {
            ui->comboBox->addItem(cityName);
        }
    }

    // 如果有匹配项，展示下拉菜单
    if (ui->comboBox->count() > 0) {
        ui->comboBox->showPopup();
    }
}

void Dialog_Change_City::on_pushButton_clicked()
{
    // 获取当前选择的城市名称
    QString selectedCity = ui->comboBox->currentText();

    if (selectedCity.isEmpty()) {
        dbg("No city selected", 0);
        return; // 如果没有选择城市，则不发送信号
    }

    // 发射信号
    emit signal_emit_city_name(selectedCity);

    // 关闭对话框
    this->accept(); // 使用 accept() 方法代替 close() 更符合对话框的关闭行为
}
