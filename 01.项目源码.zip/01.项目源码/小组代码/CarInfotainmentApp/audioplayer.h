#include <QMediaPlayer>
#include <QThread>

class AudioPlayer : public QObject {
    Q_OBJECT

public:
    AudioPlayer(QObject *parent = nullptr) : QObject(parent) {
        player = new QMediaPlayer(this);
        connect(player, &QMediaPlayer::stateChanged, this, &AudioPlayer::handleStateChanged);
    }

    ~AudioPlayer() {
        if (player) {
            delete player;
        }
    }

public slots:
    void playAudio(const QString &filePath) {
        player->setMedia(QUrl(filePath));
        player->play();
    }

    void stopAudio() {
        player->stop();
    }

signals:
    void finished();

private slots:
    void handleStateChanged(QMediaPlayer::State state) {
        if (state == QMediaPlayer::StoppedState) {
            emit finished();
        }
    }

private:
    QMediaPlayer *player;
};

