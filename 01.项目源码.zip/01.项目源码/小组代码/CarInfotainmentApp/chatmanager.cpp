#include "chatmanager.h"
#include <QDebug>

ChatManager* ChatManager::m_instance = nullptr;

ChatManager::ChatManager(QObject *parent) : QObject(parent), m_socket(nullptr)
{
}

ChatManager* ChatManager::instance()
{
    if (!m_instance) {
        m_instance = new ChatManager();
    }
    return m_instance;
}

void ChatManager::initialize(QTcpSocket *socket)
{
    m_socket = socket;
    connect(m_socket, &QTcpSocket::readyRead, this, &ChatManager::onReadyRead);
}

void ChatManager::addChatPage(const QString &username, MyChatPage *chatPage)
{
    m_chatPages[username] = chatPage;

    // 如果有缓存消息，显示这些消息
    if (m_cachedMessages.contains(username)) {
        for (const QString &message : m_cachedMessages[username]) {
            chatPage->appendMessage(message, false);  // 第二个参数为false表示这是接收到的消息
        }
        m_cachedMessages.remove(username);  // 清除已显示的缓存消息
    }
}

void ChatManager::removeChatPage(const QString &username)
{
    m_chatPages.remove(username);
}

void ChatManager::sendMessage(const QString &recipient, const QString &message)
{
    if (m_socket && m_socket->isOpen()) {
        QString fullMessage = QString("SEND:%1:%2").arg(recipient, message);
        m_socket->write(fullMessage.toUtf8() + "\n");
        m_socket->flush();  // 确保消息立即发送
    } else {
        qDebug() << "Socket is not open or connected!";
    }
}

void ChatManager::receiveMessage(const QString &sender, const QString &message)
{
    // 检查聊天页面是否打开
    if (m_chatPages.contains(sender)) {
        m_chatPages[sender]->appendMessage(sender + ": " + message, false);  // 显示收到的消息
    } else {
        m_cachedMessages[sender].append(sender + ": " + message);  // 缓存消息
        emit newMessageReceived(sender, message);  // 通知有新消息到达
    }
}

QList<QString> ChatManager::getCachedMessages(const QString &username)
{
    return m_cachedMessages.value(username);
}

void ChatManager::onReadyRead()
{
    while (m_socket->canReadLine()) {
        QString line = QString::fromUtf8(m_socket->readLine()).trimmed();
        qDebug() << "Received line:" << line;

        QStringList parts = line.split(":");
        if (parts.size() >= 2) {
            QString sender = parts[0].trimmed();  // 提取发送者
            QString message = parts.mid(1).join(":").trimmed();  // 提取消息内容
            receiveMessage(sender, message);
        } else {
            qDebug() << "Invalid message format received:" << line;
        }
    }
}
