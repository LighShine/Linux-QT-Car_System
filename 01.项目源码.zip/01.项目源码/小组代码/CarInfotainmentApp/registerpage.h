#ifndef REGISTERPAGE_H
#define REGISTERPAGE_H

#include <QDialog>
#include <QSqlDatabase>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <QCheckBox>
#include "clickablelabel.h"  // 引入自定义的ClickableLabel类

class RegisterPage : public QDialog
{
    Q_OBJECT

public:
    explicit RegisterPage(QSqlDatabase &db, QWidget *parent = nullptr);
    ~RegisterPage();

signals:
    void registrationCompleted(bool rememberUser);
    void backToLogin();

private slots:
    void handleRegister();
    void goBackToLogin();
    void chooseAvatar(); // 选择头像槽函数

private:
    void setupUI();

    QSqlDatabase &db;
    QLineEdit *nameField;
    QLineEdit *accountField;
    QLineEdit *passwordField;
    QLineEdit *confirmPasswordField;
    QPushButton *submitButton;
    QPushButton *backButton;
    ClickableLabel *avatarLabel; // 改为ClickableLabel
    QCheckBox *rememberMeCheckBox;
    QString avatarPath;
};

#endif // REGISTERPAGE_H
