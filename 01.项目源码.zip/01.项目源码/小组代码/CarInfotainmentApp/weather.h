#ifndef WEATHER_H
#define WEATHER_H

#include <QObject>
#include <QWidget>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonParseError>
#include <QJsonObject>
#include <QLabel>
#include <QTimer>
#include <QTime>
#include <QUrl>
#include <QDebug>
#include <global.h>
#include <weather_info.h>

class WEATHER : public QObject
{
    Q_OBJECT
public:
    explicit WEATHER(QObject *parent = nullptr);

    QNetworkAccessManager * manager;

    WEATHER_INFO * weather_info;

    QString getCityIdFromJson(QString city);

    /* 解析查询结果 */
    void parsingNetworkResult(QByteArray);

    /* 发送网络请求，请求获取天气信息 */
    void sendNetworkRequest(QString city);

    /* 获取当前的状态下的城市 */
    QString getCurrentCity() const;

    /* 设置当前的状态下的城市 */
    void setCurrentCity(const QString &value);

    /* 获取城市名称 */
    QString getcityName(QJsonObject obj);

    /* 获取实时温度信息 */
    QString getRealTimeTemp(QJsonObject obj);

signals:

    void signal_emit_weather_info(WEATHER_INFO *);

private slots:

    void slot_new_obj();

    void slot_refresh_manually();

    void slot_manager_read_finished(QNetworkReply *reply);

    void slot_change_local_city(QString);

    void slot_tim_update_weather();

private:

    QTimer * timForRefresh = nullptr;

    QString currentCity;



};

#endif // WEATHER_H
