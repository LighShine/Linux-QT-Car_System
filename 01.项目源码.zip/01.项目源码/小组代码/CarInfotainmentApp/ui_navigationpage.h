/********************************************************************************
** Form generated from reading UI file 'navigationpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NAVIGATIONPAGE_H
#define UI_NAVIGATIONPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_navigationpage
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *navigationpage)
    {
        if (navigationpage->objectName().isEmpty())
            navigationpage->setObjectName(QString::fromUtf8("navigationpage"));
        navigationpage->resize(800, 600);
        menubar = new QMenuBar(navigationpage);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        navigationpage->setMenuBar(menubar);
        centralwidget = new QWidget(navigationpage);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        navigationpage->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(navigationpage);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        navigationpage->setStatusBar(statusbar);

        retranslateUi(navigationpage);

        QMetaObject::connectSlotsByName(navigationpage);
    } // setupUi

    void retranslateUi(QMainWindow *navigationpage)
    {
        navigationpage->setWindowTitle(QApplication::translate("navigationpage", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class navigationpage: public Ui_navigationpage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NAVIGATIONPAGE_H
