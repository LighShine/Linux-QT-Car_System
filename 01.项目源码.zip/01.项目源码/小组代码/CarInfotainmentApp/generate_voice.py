# This Python file uses the following encoding: utf-8

# if __name__ == "__main__":
#     pass
import requests

# 获取百度Access Token
def get_access_token(api_key, secret_key):
    url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {
        "grant_type": "client_credentials",
        "client_id": AFHcdlaVN5GsZoTsgRkEHav8,
        "client_secret": yGRw1P0guj9FbhTBxR8y4m6okdPfr4FY
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.json().get("access_token")
    else:
        raise Exception("获取 access_token 失败: " + response.text)

# 生成语音文件
def text_to_speech(text, token):
    url = "https://tsn.baidu.com/text2audio"
    params = {
        "tex": text,
        "lan": "zh",  # 语言
        "tok": token,
        "cuid": "123456PYTHON",
        "ctp": 1,  # 客户端类型，固定为1
        "spd": 5,  # 语速
        "pit": 5,  # 音调
        "vol": 5,  # 音量
        "per": 4,  # 发音人
        "aue": 3   # 输出格式为MP3
    }
    response = requests.get(url, params=params)

    if response.headers['Content-Type'] == "audio/mp3":
        with open("voice_message.mp3", "wb") as f:
            f.write(response.content)
        print("语音合成成功，并已保存为 voice_message.mp3")
    else:
        print("语音合成失败:", response.text)

if __name__ == "__main__":
    API_KEY = "你的API_KEY"
    SECRET_KEY = "你的SECRET_KEY"

    # 获取Access Token
    access_token = get_access_token(API_KEY, SECRET_KEY)

    # 生成语音文件
    text_to_speech("你好，请问有什么可以帮助你吗？", access_token)
