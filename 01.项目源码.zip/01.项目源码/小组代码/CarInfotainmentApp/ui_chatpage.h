/********************************************************************************
** Form generated from reading UI file 'chatpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATPAGE_H
#define UI_CHATPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_chatpage
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *chatButton;
    QTextEdit *resultText;

    void setupUi(QWidget *chatpage)
    {
        if (chatpage->objectName().isEmpty())
            chatpage->setObjectName(QString::fromUtf8("chatpage"));
        chatpage->resize(400, 300);
        gridLayoutWidget = new QWidget(chatpage);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(110, 110, 160, 103));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        chatButton = new QPushButton(gridLayoutWidget);
        chatButton->setObjectName(QString::fromUtf8("chatButton"));

        gridLayout->addWidget(chatButton, 0, 0, 1, 1);

        resultText = new QTextEdit(gridLayoutWidget);
        resultText->setObjectName(QString::fromUtf8("resultText"));

        gridLayout->addWidget(resultText, 1, 0, 1, 1);


        retranslateUi(chatpage);

        QMetaObject::connectSlotsByName(chatpage);
    } // setupUi

    void retranslateUi(QWidget *chatpage)
    {
        chatpage->setWindowTitle(QApplication::translate("chatpage", "Form", nullptr));
        chatButton->setText(QApplication::translate("chatpage", "chatButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class chatpage: public Ui_chatpage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATPAGE_H
