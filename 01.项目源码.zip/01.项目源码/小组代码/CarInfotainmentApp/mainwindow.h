#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QLabel>
#include <QPushButton>
#include <QMediaPlayer>
#include <QAudioInput>
#include <QBuffer>
#include <QNetworkAccessManager>
#include <QPropertyAnimation>
#include <QWebEngineView>
#include "clickablelabel.h"
#include "videopage.h"
#include "musicpage.h"
#include "navigationpage.h"
#include "weatherpage.h"
#include "chatpage.h"
#include "settingspage.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void showVideoPage();
    void showMusicPage();
    void showNavigationPage();
    void showWeatherPage();
    void showChatPage();
    void showSettingsPage();
    void playVoiceMessagehello();
    void playVoiceMessagechat();
    void playVoiceMessageditu();
    void playVoiceMessagemusic();
    void playVoiceMessagevideo();
    void playVoiceMessageweather();
    void playVoiceMessagexiaozhi();
    void goHome();
    void processVoiceCommand();
    void handleVoiceRecognitionResult();

private:
    void setupAudioInput();
    void listenForKeyword();
    void setupUI();
    void setupAnimations();
void setupButtonLayouts(QVBoxLayout *leftLayout, QVBoxLayout *rightLayout);
    QStackedWidget *stackedWidget;
    QWidget *homePage;
    QLabel *timeLabel;
    ClickableLabel *centerLabel;
    QPushButton *navButton;
    QPushButton *videoButton;
    QPushButton *musicButton;
    QPushButton *weatherButton;
    QPushButton *chatButton;
    QPushButton *settingsButton;
    QMediaPlayer *player;

    QAudioInput *audioInput;
    QBuffer *audioBuffer;
    QNetworkAccessManager *networkManager;
    QWebEngineView *webView;
    QPushButton* createButton(const QString &iconPath, const QString &text);

};

#endif // MAINWINDOW_H
