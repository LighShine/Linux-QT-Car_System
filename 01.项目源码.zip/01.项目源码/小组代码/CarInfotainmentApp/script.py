# This Python file uses the following encoding: utf-8

# if __name__ == "__main__":
#     pass
import os
import json
import argparse
from zhipuai import ZhipuAI

# 大模型端口
API_KEY = "ddcf23491e7c525d165aa29b5d83a0c2.I3iYuY6raCWHw9UJ"
client = ZhipuAI(api_key=API_KEY)

parser = argparse.ArgumentParser()
parser.add_argument("--user_message", type=str, required=True, help="User message to send to the model")
args = parser.parse_args()

# 记录历史对话
chat_history = [
    {
        "role": "user",
        "content": args.user_message
    }
]

# 大模型交互
def ask(prompt):
    chat_history.append(
        {
            "role": "user",
            "content": prompt,
        }
    )
    response = client.chat.completions.create(
        model="glm-4",
        messages=chat_history,
        top_p=0.7,
        temperature=0.9,
        stream=False,
        max_tokens=3000,
    )
    response_text = response.choices[0].message.content
    return response_text

# 获取模型的响应
response = ask(args.user_message)

# 输出结果为 JSON 格式
result = {"response": response}
print(json.dumps(result))
