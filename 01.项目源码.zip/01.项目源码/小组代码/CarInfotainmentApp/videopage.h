#ifndef VIDEOPAGE_H
#define VIDEOPAGE_H

#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QSlider>
#include <QLabel>
#include <QMediaPlayer>
#include <QVideoWidget>
#include "videoplayer.h"  // 包含之前的 VideoPlayer 类

class VideoPage : public QWidget
{
    Q_OBJECT

public:
    explicit VideoPage(QWidget *parent = nullptr);

signals:
    void goHome();  // 用于返回主页的信号

private slots:
    void onAddFileBtnClicked();
    void onPauseBtnClicked();
    void onStopBtnClicked();
    void onFullScreenBtnClicked();
    void onProgressSliderMoved(int position);
    void onVolumeSliderChanged(int value);
    void updateProgressSlider();
    void setProgressSlider(int value);

private:
    VideoPlayer *videoPlayer;
    QSlider *progressSlider;
    QSlider *volumeSlider;
    QPushButton *addFileBtn;
    QPushButton *pauseBtn;
    QPushButton *stopBtn;
    QPushButton *fullScreenBtn;
    QLabel *timeLabel;
    bool isFullScreen;
    QPushButton *backBtn;
    QString formatTime(qint64 time);
};

#endif // VIDEOPAGE_H
