#include "global.h"

global::global()
{

}
