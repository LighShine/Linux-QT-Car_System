#include "navigationpage.h"
#include <QHostInfo>
#include <QDebug>
#include <QNetworkInterface>
#include <QNetworkRequest>
#include <QUrl>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QTimer>
#include <QVector>
#include <QThread>
#include <QEvent>
#include <QIcon>
#include <QVBoxLayout>
#include <QHBoxLayout>

NavigationPage::NavigationPage(QWidget *parent) :
    QMainWindow(parent)
{
    // 初始化UI组件
    edit_search = new QLineEdit(this);
    begin = new QLineEdit(this);
    end = new QLineEdit(this);
    searchBtn = new QPushButton(this);
    planRouteBtn = new QPushButton(this);
    enlargeBtn = new QPushButton(this);
    reduceBtn = new QPushButton(this);
    restartBtn = new QPushButton(this);
    backButton = new QPushButton(this);
    mapWidget = new QLabel(this);

    // 设置组件默认值和图标
    edit_search->setPlaceholderText("请输入查询地址");
    begin->setPlaceholderText("请输入出发地");
    end->setPlaceholderText("请输入目的地");

    searchBtn->setText("搜索");
    searchBtn->setIcon(QIcon(":/icons/search.png"));
    planRouteBtn->setText("规划路线");
    planRouteBtn->setIcon(QIcon(":/icons/route.png"));
    enlargeBtn->setText("放大");
    enlargeBtn->setIcon(QIcon(":/icons/fangda.png"));
    reduceBtn->setText("缩小");
    reduceBtn->setIcon(QIcon(":/icons/suoxiao.png"));
    restartBtn->setText("重置");
    restartBtn->setIcon(QIcon(":/icons/reset.png"));
    backButton->setText("返回");
    backButton->setIcon(QIcon(":/icons/back.png"));

    // 设置按钮和输入框样式
    QString buttonStyle = "QPushButton {"
                          "  background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(173, 216, 230, 0.8), stop:1 rgba(144, 238, 144, 0.8));"
                          "  color: #5D4037;"
                          "  border: 2px solid #A2D5F2;"
                          "  border-radius: 8px;"
                          "  padding: 10px;"
                          "  font-size: 16px;"
                          "  font-weight: bold;"
                          "  text-align: center;"
                          "}"
                          "QPushButton:hover {"
                          "  background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(152, 251, 152, 0.8), stop:1 rgba(135, 206, 250, 0.8));"
                          "}"
                          "QPushButton:pressed {"
                          "  background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 rgba(173, 216, 230, 0.9), stop:1 rgba(144, 238, 144, 0.9));"
                          "  border: 2px solid #8FCBDB;"
                          "}";

    searchBtn->setStyleSheet(buttonStyle);
    planRouteBtn->setStyleSheet(buttonStyle);
    enlargeBtn->setStyleSheet(buttonStyle);
    reduceBtn->setStyleSheet(buttonStyle);
    restartBtn->setStyleSheet(buttonStyle);
    backButton->setStyleSheet(buttonStyle);

    QString lineEditStyle = "QLineEdit {"
                            "  border: 1px solid #ccc;"
                            "  border-radius: 5px;"
                            "  padding: 5px;"
                            "  font-size: 16px;"
                            "}";

    edit_search->setStyleSheet(lineEditStyle);
    begin->setStyleSheet(lineEditStyle);
    end->setStyleSheet(lineEditStyle);

    // 布局设置
    QVBoxLayout *mainLayout = new QVBoxLayout;
    QHBoxLayout *topLayout = new QHBoxLayout;
    QHBoxLayout *middleLayout = new QHBoxLayout;
    QHBoxLayout *bottomLayout = new QHBoxLayout;

    topLayout->addWidget(backButton);
    topLayout->addWidget(edit_search);
    topLayout->addWidget(searchBtn);

    middleLayout->addWidget(begin);
    middleLayout->addWidget(end);
    middleLayout->addWidget(planRouteBtn);

    bottomLayout->addWidget(enlargeBtn);
    bottomLayout->addWidget(reduceBtn);
    bottomLayout->addWidget(restartBtn);

    mainLayout->addLayout(topLayout);
    mainLayout->addWidget(mapWidget);
    mainLayout->addLayout(middleLayout);
    mainLayout->addLayout(bottomLayout);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(mainLayout);
    setCentralWidget(centralWidget);

    // 连接信号和槽
    connect(searchBtn, &QPushButton::clicked, this, &NavigationPage::on_searchBtn_clicked);
    connect(planRouteBtn, &QPushButton::clicked, this, &NavigationPage::on_planRoute_clicked);
    connect(enlargeBtn, &QPushButton::clicked, this, &NavigationPage::on_enlargeBtn_clicked);
    connect(reduceBtn, &QPushButton::clicked, this, &NavigationPage::on_reduceBtn_clicked);
    connect(restartBtn, &QPushButton::clicked, this, &NavigationPage::on_restart_clicked);
    connect(backButton, &QPushButton::clicked, this, &NavigationPage::goHome);

    // 初始化其他组件和网络请求
    cont = 0;
    isPlanRoute = false;
    waypoints = " ";
    installEventFilter(this);
    init();
    getIp();
}

void NavigationPage::init(){
    m_ipManager = new QNetworkAccessManager(this);
    connect(m_ipManager, &QNetworkAccessManager::finished, this, &NavigationPage::onGetIp);

    m_locManager = new QNetworkAccessManager(this);
    connect(m_locManager, &QNetworkAccessManager::finished, this, &NavigationPage::onGetCurrentLoc);

    m_searchManager = new QNetworkAccessManager(this);
    connect(m_searchManager, &QNetworkAccessManager::finished, this, &NavigationPage::onSearchLoc);

    m_planManager = new QNetworkAccessManager(this);
    connect(m_planManager, &QNetworkAccessManager::finished, this, &NavigationPage::onPlanRoute);

    m_getwaypointManager = new QNetworkAccessManager(this);
    connect(m_getwaypointManager, &QNetworkAccessManager::finished, this, &NavigationPage::onGetwaypoint);

    m_getdrawmapManager = new QNetworkAccessManager(this);
    m_mapManager = new QNetworkAccessManager(this);
}

void NavigationPage::getIp(){
    QUrl url("http://httpbin.org/ip");
    QNetworkRequest request(url);
    m_ipManager->get(request);
}

void NavigationPage::onGetIp(QNetworkReply *reply){
    QJsonDocument jsonDoc = QJsonDocument::fromJson(reply->readAll());
    QJsonObject jsonObj = jsonDoc.object();
    currentIp = jsonObj.value("origin").toString();
    qDebug() << "Current IP:" << currentIp;
    getCurrentLoc();
}

void NavigationPage::getCurrentLoc(){
    QString host = "http://api.map.baidu.com/location/ip";
    QString query_str = QString("ip=%1&coor=bd09ll&ak=%2").arg(currentIp).arg(ak);
    QUrl url(host + "?" + query_str);
    QNetworkRequest request(url);
    m_locManager->get(request);
}

void NavigationPage::onGetCurrentLoc(QNetworkReply *reply){
    QJsonDocument jsonDoc = QJsonDocument::fromJson(reply->readAll());
    QJsonObject jsonObj = jsonDoc.object();
    QJsonObject jsonContent = jsonObj.value("content").toObject();
    QJsonObject jsonPoint = jsonContent.value("point").toObject();
    rm_lng = jsonPoint.value("x").toString().toDouble();
    rm_lat = jsonPoint.value("y").toString().toDouble();
    m_city = jsonContent.value("address_detail").toObject().value("city").toString();

    rm_lng = 116.177864;  // Test longitude
    rm_lat = 39.735586;   // Test latitude

    m_lng = rm_lng;
    m_lat = rm_lat;

    sendMapRequest();
}

void NavigationPage::sendMapRequest(){
    if(m_mapReply != nullptr){
        m_mapReply->disconnect();
        disconnect(m_mapReply, &QIODevice::readyRead, this, &NavigationPage::onSendMapRequest);
    }

    QString host;
    QString query_str;

    if (isPlanRoute) {
        planRouteCenter_lng += delta_x;
        planRouteCenter_lat -= delta_y;
        host = "https://api.map.baidu.com/staticimage/v2";
        query_str = QString("ak=%1&center=%2,%3&width=512&height=256&zoom=%4&paths=%5&pathStyles=0xff0000,5,1")
                    .arg(ak).arg(planRouteCenter_lng).arg(planRouteCenter_lat).arg(m_zoom).arg(waypoints);
    } else {
        host = "http://api.map.baidu.com/staticimage//v2";
        query_str = QString("ak=%1&width=512&height=256&center=%2,%3&zoom=%4&markers=%5,%6")
                    .arg(ak).arg(m_lng).arg(m_lat).arg(m_zoom).arg(rm_lng).arg(rm_lat);
    }

    QUrl url(host + "?" + query_str);
    QNetworkRequest request(url);
    m_mapReply = m_mapManager->get(request);
    connect(m_mapReply, &QIODevice::readyRead, this, &NavigationPage::onSendMapRequest);
}

void NavigationPage::onSendMapRequest(){
    system("del map.png");
    mapFile.setFileName(m_mapFileName);
    mapFile.open(QIODevice::WriteOnly | QIODevice::Truncate);
    m_timer.start(2);
    connect(&m_timer, &QTimer::timeout, [=](){
        m_timer.stop();
        mapFile.write(m_mapReply->readAll());
        mapFile.close();

        QPixmap pixmap;
        if(pixmap.load(m_mapFileName)){
            mapWidget->setPixmap(pixmap.scaled(mapWidget->size(), Qt::KeepAspectRatio));
        }
    });
}

void NavigationPage::on_searchBtn_clicked(){
    QString host = "https://api.map.baidu.com/geocoding/v3/";
    QString query_str = QString("address=%1&output=json&ak=%2").arg(edit_search->text()).arg(ak);
    QUrl url(host + "?" + query_str);
    QNetworkRequest request(url);
    m_searchManager->get(request);
}

void NavigationPage::onSearchLoc(QNetworkReply *reply){
    if (reply->error()) {
        qDebug() << "Network error:" << reply->errorString();
        reply->deleteLater();
        return;
    }

    QByteArray responseData = reply->readAll();
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
    if (jsonDoc.isNull()) {
        qDebug() << "Failed to parse JSON";
        reply->deleteLater();
        return;
    }

    QJsonObject jsonObject = jsonDoc.object();
    if (jsonObject.contains("status") && jsonObject["status"].toInt() == 0) {
        QJsonObject resultObject = jsonObject["result"].toObject();
        QJsonObject locationObject = resultObject["location"].toObject();
        rm_lng = locationObject["lng"].toDouble();
        rm_lat = locationObject["lat"].toDouble();
        m_lng = rm_lng;
        m_lat = rm_lat;
        qDebug() << rm_lng << rm_lat;
        sendMapRequest();
    } else {
        qDebug() << "Geocoding failed with status:" << jsonObject["status"].toString();
    }

    reply->deleteLater();
}

void NavigationPage::on_planRoute_clicked(){
    QString host = "https://api.map.baidu.com/geocoding/v3/";
    QString query_str_begin = QString("address=%1&output=json&ak=%2")
                            .arg(begin->text()).arg(ak);
    QString query_str_end = QString("address=%1&output=json&ak=%2")
                            .arg(end->text()).arg(ak);

    QUrl url_b(host + "?" + query_str_begin);
    QUrl url_e(host + "?" + query_str_end);

    QNetworkRequest request_b(url_b);
    QNetworkRequest request_e(url_e);

    m_planManager->get(request_b);
    QThread::msleep(100);
    m_planManager->get(request_e);
}

void NavigationPage::onPlanRoute(QNetworkReply *reply){
    if (reply->error()) {
        qDebug() << "Network error:" << reply->errorString();
        reply->deleteLater();
        return;
    }

    QByteArray responseData = reply->readAll();
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
    if (jsonDoc.isNull()) {
        qDebug() << "Failed to parse JSON";
        reply->deleteLater();
        return;
    }

    QJsonObject jsonObject = jsonDoc.object();
    if (jsonObject.contains("status") && jsonObject["status"].toInt() == 0) {
        QJsonObject resultObject = jsonObject["result"].toObject();
        QJsonObject locationObject = resultObject["location"].toObject();
        be_lng[cont] = locationObject["lng"].toDouble();
        be_lat[cont] = locationObject["lat"].toDouble();
        qDebug() << be_lng[cont] << be_lat[cont];

        if(cont == 1) {
            getwaypoint();
            cont = 0;
        } else {
            cont++;
        }
    } else {
        qDebug() << "Geocoding failed with status:" << jsonObject["status"].toString();
    }

    reply->deleteLater();
}

void NavigationPage::getwaypoint(){
    QString host = "https://api.map.baidu.com/directionlite/v1/";
    QString query_str = QString("driving?origin=%1,%2&destination=%3,%4&ak=%5")
            .arg(be_lat[0]).arg(be_lng[0]).arg(be_lat[1]).arg(be_lng[1]).arg(ak);

    QUrl url(host + query_str);
    QNetworkRequest request(url);
    m_getwaypointManager->get(request);
}

void NavigationPage::onGetwaypoint(QNetworkReply *reply){
    if (reply->error()) {
        qDebug() << "Network error:" << reply->errorString();
        reply->deleteLater();
        return;
    }

    QByteArray responseData = reply->readAll();
    QString responseString = QString::fromUtf8(responseData);
    QJsonDocument jsonDoc = QJsonDocument::fromJson(responseString.toUtf8());
    if (jsonDoc.isNull()) {
        qDebug() << "Failed to parse JSON";
        reply->deleteLater();
        return;
    }

    QJsonObject jsonObject = jsonDoc.object();
    if (jsonObject.contains("status") && jsonObject["status"].toInt() == 0) {
        QJsonObject resultObject = jsonObject["result"].toObject();
        QJsonArray routesArray = resultObject["routes"].toArray();

        waypoints = QString::number(be_lng[0]) + "," + QString::number(be_lat[0]) + ";";

        int pointNum = 0;
        for (const QJsonValue &routeValue : routesArray) {
            if (routeValue.isObject()) {
                QJsonObject routeObj = routeValue.toObject();
                if (routeObj.contains("steps") && routeObj["steps"].isArray()) {
                    QJsonArray stepsArray = routeObj["steps"].toArray();
                    for (const QJsonValue &stepValue : stepsArray) {
                        if (stepValue.isObject()) {
                            QJsonObject stepObj = stepValue.toObject();
                            if (stepObj.contains("path")) {
                                QString path = stepObj["path"].toString();
                                waypoints += path + ";";
                                pointNum += path.count(';') + 1;
                            }
                        }
                    }
                }
            }
        }

        if (pointNum > 150) {
            QStringList points = waypoints.split(';');
            waypoints.clear();
            int step = qMax(1, points.size() / 150);
            for (int i = 0; i < points.size(); i += step) {
                waypoints += points[i] + ";";
            }
        }

        waypoints += QString::number(be_lng[1]) + "," + QString::number(be_lat[1]);

        isPlanRoute = true;
        planRouteCenter_lng = (be_lng[0] + be_lng[1]) / 2;
        planRouteCenter_lat = (be_lat[0] + be_lat[1]) / 2;
        sendMapRequest();

    } else {
        qDebug() << "Geocoding failed with status:" << jsonObject["status"].toString();
    }

    reply->deleteLater();
}

void NavigationPage::getdrawmap(QString waypoints){
    QString host = "https://api.map.baidu.com/staticimage/v2";
    QString query_str = QString("ak=%1&center=%2,%3&width=500&height=500&zoom=11&paths=%4&pathStyles=0xff0000,5,1")
                            .arg(ak).arg(be_lng[0]).arg(be_lat[0]).arg(waypoints);

    QUrl url(host + "?" + query_str);
    QNetworkRequest request(url);
    m_mapReply = m_getdrawmapManager->get(request);
    connect(m_mapReply, &QIODevice::readyRead, this, &NavigationPage::onSendMapRequest);
}

void NavigationPage::on_enlargeBtn_clicked(){
    if(m_zoom < 19){
        m_zoom += 1;
        sendMapRequest();
    }
}

void NavigationPage::on_reduceBtn_clicked(){
    if(m_zoom > 3){
        m_zoom -= 1;
        sendMapRequest();
    }
}

void NavigationPage::on_restart_clicked(){
    getIp();
    edit_search->setText("请输入查询地址");
    begin->setText("请输入出发地");
    end->setText("请输入目的地");
    cont = 0;
    isPlanRoute = false;
    waypoints = " ";
}

bool NavigationPage::eventFilter(QObject *watched, QEvent *event){
    if(event->type() == QEvent::MouseButtonPress){
        qDebug() << event->type() << cursor().pos().x() << ":" << cursor().pos().y();
        isPress = true;
        startPoint.setX(cursor().pos().x());
        startPoint.setY(cursor().pos().y());
    }

    if(event->type() == QEvent::MouseButtonRelease){
        qDebug() << event->type() << cursor().pos().x() << ":" << cursor().pos().y();
        isRelease = true;
        endPoint.setX(cursor().pos().x());
        endPoint.setY(cursor().pos().y());
    }

    if(isPress && isRelease){
        isPress = false;
        isRelease = false;
        mx = startPoint.x() - endPoint.x();
        my = startPoint.y() - endPoint.y();

        if(qAbs(mx) > 5 || qAbs(my) > 5){
            delta_x = mx * 0.000002 * (19 - m_zoom) * (19 - m_zoom);
            delta_y = my * 0.000002 * (19 - m_zoom) * (19 - m_zoom);
            m_lng += delta_x;
            m_lat -= delta_y;
            sendMapRequest();
        }
    }

    return QWidget::eventFilter(watched, event);
}

NavigationPage::~NavigationPage()
{
    delete edit_search;
    delete begin;
    delete end;
    delete searchBtn;
    delete planRouteBtn;
    delete enlargeBtn;
    delete reduceBtn;
    delete restartBtn;
    delete mapWidget;
}
