#include "musicpage.h"
#include <QFileInfo>
#include <QUrl>
#include <QPalette>
#include <QBrush>
#include <QPixmap>
#include <QTextStream>
#include <QMessageBox>
#include <QFile>
#include <QTime>  // 添加这一行来包含 QTime 类

MusicPage::MusicPage(QWidget *parent)
    : QWidget(parent),
      player(new QMediaPlayer(this)),
      playlist(new QMediaPlaylist(this)),
      lyricsTimer(new QTimer(this))
{
    setupUI();
    player->setPlaylist(playlist);
    player->setVolume(50);  // 默认音量

    // 连接信号和槽
    connect(playButton, &QPushButton::clicked, this, &MusicPage::playMusic);
    connect(pauseButton, &QPushButton::clicked, this, &MusicPage::pauseMusic);
    connect(stopButton, &QPushButton::clicked, this, &MusicPage::stopMusic);
    connect(openButton, &QPushButton::clicked, this, &MusicPage::openFile);
    connect(nextButton, &QPushButton::clicked, this, &MusicPage::nextTrack);
    connect(prevButton, &QPushButton::clicked, this, &MusicPage::previousTrack);
    connect(volumeSlider, &QSlider::valueChanged, this, &MusicPage::changeVolume);
    connect(player, &QMediaPlayer::positionChanged, this, &MusicPage::updatePosition);
    connect(player, &QMediaPlayer::durationChanged, this, &MusicPage::updateDuration);
    connect(positionSlider, &QSlider::sliderMoved, this, &MusicPage::setPosition);
    connect(lyricsTimer, &QTimer::timeout, this, &MusicPage::updateLyrics);
    connect(favoriteButton, &QPushButton::clicked, this, &MusicPage::toggleFavorite);
    connect(saveButton, &QPushButton::clicked, this, &MusicPage::savePlaylist);
    connect(loadButton, &QPushButton::clicked, this, &MusicPage::loadPlaylist);

    lyricsTimer->start(1000);  // 每秒更新一次歌词
}

MusicPage::~MusicPage()
{
    delete player;
    delete playlist;
}

void MusicPage::setupUI()
{
    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    // 设置背景图像
    QPalette pal;
    pal.setBrush(QPalette::Background, QBrush(QPixmap(":/images/background_music.jpg").scaled(size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
    this->setAutoFillBackground(true);
    this->setPalette(pal);

    // 顶部标签
    QLabel *titleLabel = new QLabel(tr("Enjoy Your Journey"), this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setStyleSheet("font-size: 36px; color: white; font-family: 'Segoe UI', sans-serif;");

    // 控制按钮布局
    playButton = new QPushButton(this);
    pauseButton = new QPushButton(this);
    stopButton = new QPushButton(this);
    nextButton = new QPushButton(this);
    prevButton = new QPushButton(this);
    favoriteButton = new QPushButton(this);
    openButton = new QPushButton(tr("Open"), this);
    saveButton = new QPushButton(tr("Save Playlist"), this);
    loadButton = new QPushButton(tr("Load Playlist"), this);

    // 设置按钮图标
    playButton->setIcon(QIcon(":/icons/play.png"));
    pauseButton->setIcon(QIcon(":/icons/pause.png"));
    stopButton->setIcon(QIcon(":/icons/pause.png"));
    nextButton->setIcon(QIcon(":/icons/xia.png"));
    prevButton->setIcon(QIcon(":/icons/shang.png"));
    favoriteButton->setIcon(QIcon(":/icons/heart.png"));

    // 自定义按钮样式
    QString buttonStyle = "QPushButton {"
                          "background-color: rgba(255, 255, 255, 0.3);"
                          "border-radius: 15px;"
                          "padding: 10px;"
                          "}"
                          "QPushButton:pressed {"
                          "background-color: rgba(255, 255, 255, 0.6);"
                          "}";

    playButton->setStyleSheet(buttonStyle);
    pauseButton->setStyleSheet(buttonStyle);
    stopButton->setStyleSheet(buttonStyle);
    nextButton->setStyleSheet(buttonStyle);
    prevButton->setStyleSheet(buttonStyle);
    favoriteButton->setStyleSheet(buttonStyle);
    openButton->setStyleSheet(buttonStyle);
    saveButton->setStyleSheet(buttonStyle);
    loadButton->setStyleSheet(buttonStyle);

    // 播放位置和音量控制
    positionSlider = new QSlider(Qt::Horizontal, this);
    positionSlider->setRange(0, 0);
    positionSlider->setStyleSheet("QSlider::groove:horizontal {"
                                  "border: 1px solid #999999;"
                                  "height: 8px;"
                                  "background: rgba(255, 255, 255, 0.4);"
                                  "}"
                                  "QSlider::handle:horizontal {"
                                  "background: white;"
                                  "border: 1px solid #5c5c5c;"
                                  "width: 18px;"
                                  "margin: -8px 0;"
                                  "border-radius: 9px;"
                                  "}");

    volumeSlider = new QSlider(Qt::Vertical, this);
    volumeSlider->setRange(0, 100);
    volumeSlider->setValue(player->volume());
    volumeSlider->setStyleSheet("QSlider::groove:vertical {"
                                "border: 1px solid #999999;"
                                "width: 8px;"
                                "background: rgba(255, 255, 255, 0.4);"
                                "}"
                                "QSlider::handle:vertical {"
                                "background: white;"
                                "border: 1px solid #5c5c5c;"
                                "height: 18px;"
                                "margin: 0 -8px;"
                                "border-radius: 9px;"
                                "}");

    durationLabel = new QLabel(tr("00:00 / 00:00"), this);
    durationLabel->setStyleSheet("font-size: 16px; color: white;");

    // 歌词显示
    lyricsBrowser = new QTextBrowser(this);
    lyricsBrowser->setStyleSheet("font-size: 18px; color: white; background: transparent; border: none;");
    lyricsBrowser->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    lyricsBrowser->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    // 播放列表
    playlistWidget = new QListWidget(this);
    playlistWidget->setStyleSheet("background: rgba(255, 255, 255, 0.1); color: white; font-size: 16px;");

    // 布局安排
    QHBoxLayout *controlLayout = new QHBoxLayout;
    controlLayout->addWidget(prevButton);
    controlLayout->addWidget(playButton);
    controlLayout->addWidget(pauseButton);
    controlLayout->addWidget(stopButton);
    controlLayout->addWidget(nextButton);
    controlLayout->addWidget(favoriteButton);

    QHBoxLayout *sliderLayout = new QHBoxLayout;
    sliderLayout->addWidget(positionSlider);
    sliderLayout->addWidget(durationLabel);

    QVBoxLayout *volumeLayout = new QVBoxLayout;
    volumeLayout->addWidget(volumeSlider);
    volumeLayout->addStretch();

    QVBoxLayout *rightLayout = new QVBoxLayout;
    rightLayout->addWidget(openButton);
    rightLayout->addWidget(saveButton);
    rightLayout->addWidget(loadButton);
    rightLayout->addStretch();

    QHBoxLayout *bottomLayout = new QHBoxLayout;
    bottomLayout->addLayout(volumeLayout);
    bottomLayout->addLayout(controlLayout);
    bottomLayout->addLayout(rightLayout);

    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(lyricsBrowser);
    mainLayout->addWidget(playlistWidget);
    mainLayout->addLayout(sliderLayout);
    mainLayout->addLayout(bottomLayout);
}

void MusicPage::playMusic()
{
    player->play();
}

void MusicPage::pauseMusic()
{
    player->pause();
}

void MusicPage::stopMusic()
{
    player->stop();
}

void MusicPage::openFile()
{
    QFileDialog fileDialog(this, tr("打开音频文件"), QString(), tr("音频文件 (*.mp3 *.wav)"));
    fileDialog.setOption(QFileDialog::DontUseNativeDialog);
    if (fileDialog.exec() == QDialog::Accepted) {
        QStringList fileNames = fileDialog.selectedFiles();
        for (const QString &fileName : fileNames) {
            if (!fileName.isEmpty()) {
                loadMusicFile(fileName);
            }
        }
    }
}

void MusicPage::loadMusicFile(const QString &filePath)
{
    playlist->addMedia(QUrl::fromLocalFile(filePath));
    QFileInfo fileInfo(filePath);
    playlistWidget->addItem(fileInfo.fileName());
    loadLyrics(filePath);

    if (playlist->mediaCount() == 1) {
        player->play();
    }
}

void MusicPage::nextTrack()
{
    playlist->next();
}

void MusicPage::previousTrack()
{
    playlist->previous();
}

void MusicPage::changeVolume(int volume)
{
    player->setVolume(volume);
}

void MusicPage::updatePosition(qint64 position)
{
    positionSlider->setValue(position);
    durationLabel->setText(formatTime(position) + " / " + formatTime(player->duration()));
}

void MusicPage::setPosition(int position)
{
    player->setPosition(position);
}

void MusicPage::updateDuration(qint64 duration)
{
    positionSlider->setRange(0, duration);
}

void MusicPage::updateLyrics()
{
    if (!currentTrack.isEmpty() && lyricsMap.contains(currentTrack)) {
        QStringList lyrics = lyricsMap[currentTrack].split("\n");
        qint64 currentTime = player->position();
        QString currentLyric;

        for (const QString &line : lyrics) {
            QStringList parts = line.split("]");
            if (parts.size() > 1) {
                QString timeString = parts[0].mid(1);
                QTime time = QTime::fromString(timeString, "mm:ss");
                qint64 ms = QTime(0, time.minute(), time.second()).msecsSinceStartOfDay();
                if (currentTime >= ms) {
                    currentLyric = parts[1];
                }
            }
        }

        lyricsBrowser->setText(currentLyric);
    }
}

void MusicPage::toggleFavorite()
{
    if (!currentTrack.isEmpty() && !favoriteSongs.contains(currentTrack)) {
        favoriteSongs.append(currentTrack);
        QMessageBox::information(this, tr("收藏"), tr("歌曲已添加到收藏列表！"));
    }
}

void MusicPage::savePlaylist()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("保存播放列表"), "", tr("播放列表文件 (*.m3u)"));
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("保存失败"), tr("无法保存播放列表文件"));
        return;
    }

    QTextStream out(&file);
    for (int i = 0; i < playlist->mediaCount(); ++i) {
        QUrl url = playlist->media(i).canonicalUrl();
        if (url.isLocalFile()) {
            out << url.toLocalFile() << "\n";
        }
    }

    file.close();
    QMessageBox::information(this, tr("保存成功"), tr("播放列表已保存"));
}

void MusicPage::loadPlaylist()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("加载播放列表"), "", tr("播放列表文件 (*.m3u)"));
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, tr("加载失败"), tr("无法加载播放列表文件"));
        return;
    }

    playlist->clear();
    playlistWidget->clear();

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        loadMusicFile(line);
    }

    file.close();
    QMessageBox::information(this, tr("加载成功"), tr("播放列表已加载"));
}

QString MusicPage::formatTime(qint64 time)
{
    int seconds = (time / 1000) % 60;
    int minutes = (time / 60000) % 60;
    return QString("%1:%2").arg(minutes, 2, 10, QChar('0')).arg(seconds, 2, 10, QChar('0'));
}

void MusicPage::loadLyrics(const QString &filePath)
{
    QString lyricsFilePath = filePath;
    lyricsFilePath.chop(4); // Remove ".mp3" or ".wav"
    lyricsFilePath += ".lrc"; // Assume lyrics are stored in .lrc files

    QFile file(lyricsFilePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        lyricsMap[filePath] = "";  // No lyrics available
        return;
    }

    QTextStream in(&file);
    QString lyricsContent = in.readAll();
    lyricsMap[filePath] = lyricsContent;
    file.close();
}
