#ifndef NAVIGATIONPAGE_H
#define NAVIGATIONPAGE_H

#include <QMainWindow>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QNetworkAccessManager>
#include <QTimer>
#include <QFile>
#include <QPoint>
#include <QVector>

class NavigationPage : public QMainWindow
{
    Q_OBJECT

public:
    explicit NavigationPage(QWidget *parent = nullptr);
    ~NavigationPage();

signals:
    void goHome();  // 将返回主界面的槽函数声明为信号

private slots:
    void on_searchBtn_clicked();
    void on_planRoute_clicked();
    void on_enlargeBtn_clicked();
    void on_reduceBtn_clicked();
    void on_restart_clicked();

    void onGetIp(QNetworkReply*);
    void onGetCurrentLoc(QNetworkReply*);
    void onSendMapRequest();
    void onSearchLoc(QNetworkReply*);
    void onPlanRoute(QNetworkReply*);
    void onGetwaypoint(QNetworkReply*);
    void getdrawmap(QString waypoints);

private:
    void init();
    void getIp();
    void getCurrentLoc();
    void sendMapRequest();
    void getwaypoint();

    // UI 组件
    QLineEdit *edit_search;
    QLineEdit *begin;
    QLineEdit *end;
    QPushButton *searchBtn;
    QPushButton *planRouteBtn;
    QPushButton *enlargeBtn;
    QPushButton *reduceBtn;
    QPushButton *restartBtn;
    QPushButton *backButton;

    QLabel *mapWidget;

    // 网络管理器
    QNetworkAccessManager *m_ipManager;
    QNetworkAccessManager *m_locManager;
    QNetworkAccessManager *m_searchManager;
    QNetworkAccessManager *m_planManager;
    QNetworkAccessManager *m_getwaypointManager;
    QNetworkAccessManager *m_getdrawmapManager;
    QNetworkAccessManager *m_mapManager;
    QNetworkReply *m_mapReply = nullptr;

    // 地图和位置信息
    QString ak = "yYSnHDIgAbSRlyktehYXmvlzA0s3eEhX";
    QString currentIp;
    double rm_lng;
    double rm_lat;
    double m_lng;
    double m_lat;
    QVector<double> waypoint_lng;
    QVector<double> waypoint_lat;
    double be_lng[2];
    double be_lat[2];
    int cont;
    int m_zoom = 15;
    QString m_city;
    QString m_mapFileName = "map.png";
    QTimer m_timer;
    QFile mapFile;

    // 路线规划状态和参数
    bool isPlanRoute = false;  // 路线规划标志
    double planRouteCenter_lng;  // 路线规划中心点经度
    double planRouteCenter_lat;  // 路线规划中心点纬度
    QString waypoints;  // 路径点

    // 鼠标事件处理
    bool isPress = false;
    bool isRelease = false;
    QPoint startPoint;
    QPoint endPoint;
    double mx;
    double my;
    // 新增的变量声明
        double delta_x;  // X轴方向的偏移量
        double delta_y;  // Y轴方向的偏移量

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;
};

#endif // NAVIGATIONPAGE_H
