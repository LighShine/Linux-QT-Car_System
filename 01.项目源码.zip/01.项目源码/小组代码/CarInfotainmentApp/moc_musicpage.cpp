/****************************************************************************
** Meta object code from reading C++ file 'musicpage.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "musicpage.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'musicpage.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MusicPage_t {
    QByteArrayData data[30];
    char stringdata0[467];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MusicPage_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MusicPage_t qt_meta_stringdata_MusicPage = {
    {
QT_MOC_LITERAL(0, 0, 9), // "MusicPage"
QT_MOC_LITERAL(1, 10, 6), // "goHome"
QT_MOC_LITERAL(2, 17, 0), // ""
QT_MOC_LITERAL(3, 18, 12), // "showPlayList"
QT_MOC_LITERAL(4, 31, 12), // "showLikeList"
QT_MOC_LITERAL(5, 44, 17), // "setProgressSlider"
QT_MOC_LITERAL(6, 62, 6), // "number"
QT_MOC_LITERAL(7, 69, 16), // "onFileBtnClicked"
QT_MOC_LITERAL(8, 86, 17), // "onPauseBtnClicked"
QT_MOC_LITERAL(9, 104, 28), // "onProgressSliderValueChanged"
QT_MOC_LITERAL(10, 133, 5), // "value"
QT_MOC_LITERAL(11, 139, 24), // "onProgressSliderReleased"
QT_MOC_LITERAL(12, 164, 20), // "onVolumeUpBtnClicked"
QT_MOC_LITERAL(13, 185, 22), // "onVolumeDownBtnClicked"
QT_MOC_LITERAL(14, 208, 15), // "onEndBtnClicked"
QT_MOC_LITERAL(15, 224, 20), // "onPlayListBtnClicked"
QT_MOC_LITERAL(16, 245, 16), // "onNextBtnClicked"
QT_MOC_LITERAL(17, 262, 16), // "onLastBtnClicked"
QT_MOC_LITERAL(18, 279, 16), // "onLikeBtnClicked"
QT_MOC_LITERAL(19, 296, 20), // "onLikeListBtnClicked"
QT_MOC_LITERAL(20, 317, 21), // "onPlayOrderBtnClicked"
QT_MOC_LITERAL(21, 339, 11), // "updateLyric"
QT_MOC_LITERAL(22, 351, 27), // "onPlayListItemDoubleClicked"
QT_MOC_LITERAL(23, 379, 16), // "QListWidgetItem*"
QT_MOC_LITERAL(24, 396, 4), // "item"
QT_MOC_LITERAL(25, 401, 27), // "onLikeListItemDoubleClicked"
QT_MOC_LITERAL(26, 429, 12), // "displayLyric"
QT_MOC_LITERAL(27, 442, 8), // "position"
QT_MOC_LITERAL(28, 451, 10), // "formatTime"
QT_MOC_LITERAL(29, 462, 4) // "time"

    },
    "MusicPage\0goHome\0\0showPlayList\0"
    "showLikeList\0setProgressSlider\0number\0"
    "onFileBtnClicked\0onPauseBtnClicked\0"
    "onProgressSliderValueChanged\0value\0"
    "onProgressSliderReleased\0onVolumeUpBtnClicked\0"
    "onVolumeDownBtnClicked\0onEndBtnClicked\0"
    "onPlayListBtnClicked\0onNextBtnClicked\0"
    "onLastBtnClicked\0onLikeBtnClicked\0"
    "onLikeListBtnClicked\0onPlayOrderBtnClicked\0"
    "updateLyric\0onPlayListItemDoubleClicked\0"
    "QListWidgetItem*\0item\0onLikeListItemDoubleClicked\0"
    "displayLyric\0position\0formatTime\0time"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MusicPage[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,  125,    2, 0x08 /* Private */,
       4,    0,  126,    2, 0x08 /* Private */,
       5,    1,  127,    2, 0x08 /* Private */,
       7,    0,  130,    2, 0x08 /* Private */,
       8,    0,  131,    2, 0x08 /* Private */,
       9,    1,  132,    2, 0x08 /* Private */,
      11,    0,  135,    2, 0x08 /* Private */,
      12,    0,  136,    2, 0x08 /* Private */,
      13,    0,  137,    2, 0x08 /* Private */,
      14,    0,  138,    2, 0x08 /* Private */,
      15,    0,  139,    2, 0x08 /* Private */,
      16,    0,  140,    2, 0x08 /* Private */,
      17,    0,  141,    2, 0x08 /* Private */,
      18,    0,  142,    2, 0x08 /* Private */,
      19,    0,  143,    2, 0x08 /* Private */,
      20,    0,  144,    2, 0x08 /* Private */,
      21,    0,  145,    2, 0x08 /* Private */,
      22,    1,  146,    2, 0x08 /* Private */,
      25,    1,  149,    2, 0x08 /* Private */,
      26,    1,  152,    2, 0x08 /* Private */,
      28,    1,  155,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void, 0x80000000 | 23,   24,
    QMetaType::Void, QMetaType::LongLong,   27,
    QMetaType::QString, QMetaType::LongLong,   29,

       0        // eod
};

void MusicPage::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MusicPage *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->goHome(); break;
        case 1: _t->showPlayList(); break;
        case 2: _t->showLikeList(); break;
        case 3: _t->setProgressSlider((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->onFileBtnClicked(); break;
        case 5: _t->onPauseBtnClicked(); break;
        case 6: _t->onProgressSliderValueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->onProgressSliderReleased(); break;
        case 8: _t->onVolumeUpBtnClicked(); break;
        case 9: _t->onVolumeDownBtnClicked(); break;
        case 10: _t->onEndBtnClicked(); break;
        case 11: _t->onPlayListBtnClicked(); break;
        case 12: _t->onNextBtnClicked(); break;
        case 13: _t->onLastBtnClicked(); break;
        case 14: _t->onLikeBtnClicked(); break;
        case 15: _t->onLikeListBtnClicked(); break;
        case 16: _t->onPlayOrderBtnClicked(); break;
        case 17: _t->updateLyric(); break;
        case 18: _t->onPlayListItemDoubleClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 19: _t->onLikeListItemDoubleClicked((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 20: _t->displayLyric((*reinterpret_cast< qint64(*)>(_a[1]))); break;
        case 21: { QString _r = _t->formatTime((*reinterpret_cast< qint64(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MusicPage::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MusicPage::goHome)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MusicPage::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_MusicPage.data,
    qt_meta_data_MusicPage,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MusicPage::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MusicPage::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MusicPage.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int MusicPage::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}

// SIGNAL 0
void MusicPage::goHome()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
