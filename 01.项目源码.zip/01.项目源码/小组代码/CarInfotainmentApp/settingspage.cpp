#include "settingspage.h"
#include "registerpage.h"
#include "userlistpage.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QPixmap>
#include <QDebug>
#include <QApplication>
#include <QTcpSocket>
#include <QHostAddress>
#include "mychatpage.h"

SettingsPage::SettingsPage(QWidget *parent) : QWidget(parent)
{
    setupUI();
    setupDatabase();
}

SettingsPage::~SettingsPage()
{
    if (db.isOpen()) {
        db.close();
    }
    if (tcpSocket) {
        tcpSocket->disconnectFromHost();
        tcpSocket->deleteLater();
    }
    if (userListPage) {
        delete userListPage;
    }
}

void SettingsPage::setupUI()
{
    qDebug() << "Setup UI started.";

    // 主布局设置
    QHBoxLayout *mainLayout = new QHBoxLayout(this);
    mainLayout->setContentsMargins(0, 0, 0, 0); // 设置边距为零
    mainLayout->setSpacing(0); // 设置组件之间的间距为零

    // 图像区域
    QWidget *leftWidget = new QWidget(this);
    leftWidget->setStyleSheet("background-color: #2F4F4F;"); // 深灰绿色背景
    QVBoxLayout *leftLayout = new QVBoxLayout(leftWidget);

    QLabel *illustrationLabel = new QLabel(leftWidget);
    QPixmap pixmap(":/images/log_image1.png");
    if (pixmap.isNull()) {
        qDebug() << "Failed to load image :/images/log_image1.png";
    }
    illustrationLabel->setPixmap(pixmap.scaled(600, 600, Qt::KeepAspectRatio, Qt::SmoothTransformation)); // 插画图像
    illustrationLabel->setAlignment(Qt::AlignCenter);
    leftLayout->addWidget(illustrationLabel, 0, Qt::AlignCenter);

    mainLayout->addWidget(leftWidget, 3);  // 左侧宽度比例

    // 右侧表单区域
    QWidget *rightWidget = new QWidget(this);
    rightWidget->setStyleSheet("background-color: #FFCC66;"); // 黄色背景
    QVBoxLayout *rightLayout = new QVBoxLayout(rightWidget);

    // 表单框架设置
    QFrame *formFrame = new QFrame(this);
    formFrame->setStyleSheet(
        "background-color: white; " // 白色背景
        "padding: 50px; "
        "border-radius: 20px;" // 更大的圆角
        "box-shadow: 0px 12px 24px rgba(0, 0, 0, 0.2);" // 更大的阴影
    );
    formFrame->setFixedSize(450, 500); // 增大表单框架大小

    QVBoxLayout *formLayout = new QVBoxLayout(formFrame);

    QLabel *headerLabel = new QLabel("ALREADY MEMBERS", formFrame);
    headerLabel->setStyleSheet("color: #FFCC66; font-size: 22px; font-weight: bold; margin-bottom: 25px;"); // 顶部标题更大
    headerLabel->setAlignment(Qt::AlignCenter);
    formLayout->addWidget(headerLabel);

    // 帐号输入框设置
    accountField = new QLineEdit(formFrame);
    accountField->setPlaceholderText("Enter your email");
    accountField->setStyleSheet(
        "background-color: #F0F0F0; "
        "color: #333; "
        "font-size: 16px; "
        "border: 1px solid #DDD; "
        "padding: 15px; "  // 更高的输入框
        "margin-bottom: 30px; "
        "border-radius: 10px;" // 更大的圆角输入框
    );

    // 密码输入框设置
    passwordField = new QLineEdit(formFrame);
    passwordField->setEchoMode(QLineEdit::Password);
    passwordField->setPlaceholderText("Enter your password");
    passwordField->setStyleSheet(
        "background-color: #F0F0F0; "
        "color: #333; "
        "font-size: 16px; "
        "border: 1px solid #DDD; "
        "padding: 15px; "  // 更高的输入框
        "margin-bottom: 30px; "
        "border-radius: 10px;" // 更大的圆角输入框
    );

    // 登录按钮设置
    loginButton = new QPushButton("LOG IN", formFrame);
    loginButton->setStyleSheet(
        "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 #3D85C6, stop:1 #3F7BB6); " // 渐变背景
        "color: white; "
        "padding: 23px; " // 更高的按钮
        "font-size: 18px; " // 更大的字体
        "border-radius: 10px; "
        "margin-bottom: 20px;"
        "border: none;"
        "font-weight: bold;" // 加粗字体
    );

    registerButton = new QPushButton("SIGN UP", formFrame);
    registerButton->setStyleSheet(
        "background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, stop:0 #66A2CC, stop:1 #5C91B6); " // 渐变背景
        "color: white; "
        "padding: 23px; " // 更高的按钮
        "font-size: 18px; " // 更大的字体
        "border-radius: 10px; "
        "margin-bottom: 20px;"
        "border: none;"
        "font-weight: bold;" // 加粗字体
    );

    backButton = new QPushButton("返回", formFrame);
    backButton->setStyleSheet(
        "background-color: #FFFFFF; "
        "color: #66A2CC; "
        "padding: 15px; " // 更高的按钮
        "font-size: 18px; " // 更大的字体
        "border-radius: 10px; "
        "border: 2px solid #66A2CC; "
        "font-weight: bold;" // 加粗字体
    );

    QLabel *helpLabel = new QLabel("Need help?", formFrame);
    helpLabel->setStyleSheet("color: #888; font-size: 14px; margin-top: 15px;");
    helpLabel->setAlignment(Qt::AlignRight);

    formLayout->addWidget(accountField);
    formLayout->addWidget(passwordField);
    formLayout->addWidget(loginButton);
    formLayout->addWidget(registerButton);
    formLayout->addWidget(helpLabel);
    formLayout->addStretch(1);
    formLayout->addWidget(backButton);

    rightLayout->addStretch(1); // 增加顶部和底部空白
    rightLayout->addWidget(formFrame, 0, Qt::AlignCenter); // 表单框架居中对齐
    rightLayout->addStretch(1);

    QLabel *footerLabel = new QLabel("Don't have an account yet? Create an account", rightWidget);
    footerLabel->setStyleSheet("color: #4B4B4B; font-size: 14px; margin-top: 30px;");
    footerLabel->setAlignment(Qt::AlignCenter);
    rightLayout->addWidget(footerLabel, 0, Qt::AlignCenter);

    mainLayout->addWidget(rightWidget, 2); // 右侧宽度比例

    setLayout(mainLayout);

    // 信号与槽连接
    connect(loginButton, &QPushButton::clicked, this, &SettingsPage::handleLogin);
    connect(registerButton, &QPushButton::clicked, this, &SettingsPage::showRegisterPage);
    connect(backButton, &QPushButton::clicked, this, &SettingsPage::goHome);

    qDebug() << "Setup UI completed.";
}


void SettingsPage::setupDatabase()
{
    if (!QSqlDatabase::contains("qt_sql_default_connection")) {
        db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("my_new_app.db");
    } else {
        db = QSqlDatabase::database("qt_sql_default_connection");
    }

    if (!db.isOpen()) {
        if (!db.open()) {
            QMessageBox::critical(this, "Database Error", "Unable to open the database: " + db.lastError().text());
            qDebug() << "Error opening database:" << db.lastError().text();
            return;
        }
    }

    QSqlQuery query;
    if (!query.exec("CREATE TABLE IF NOT EXISTS users ("
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                    "account TEXT UNIQUE, "
                    "password TEXT, "
                    "username TEXT, "
                    "avatar TEXT)")) {
        QMessageBox::critical(this, "Database Error", "Failed to create users table: " + query.lastError().text());
        qDebug() << "Error creating table:" << query.lastError().text();
    }
}

void SettingsPage::handleLogin()
{
    QString account = accountField->text();
    QString password = passwordField->text();

    if (account.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Account and password must not be empty.");
        return;
    }

    if (!db.isOpen()) {
        QMessageBox::critical(this, "Database Error", "Database is not open!");
        return;
    }

    QSqlQuery query(db);
    query.prepare("SELECT password FROM users WHERE account = :account");
    query.bindValue(":account", account);

    if (!query.exec()) {
        QMessageBox::critical(this, "Database Error", "Failed to execute query: " + query.lastError().text());
        qDebug() << "Error executing query:" << query.lastError().text();
        return;
    }

    if (query.next()) {
        QString storedPassword = query.value(0).toString();
        if (storedPassword == password) {
            qDebug() << "Login successful, creating UserListPage...";

            tcpSocket = new QTcpSocket(this);
            tcpSocket->connectToHost(QHostAddress("127.0.0.1"), 5678);
            if (tcpSocket->waitForConnected(3000)) {
                tcpSocket->write(("REGISTER:" + account + "\n").toUtf8());
                connect(tcpSocket, &QTcpSocket::readyRead, this, &SettingsPage::readServerResponse);
            } else {
                QMessageBox::warning(this, "错误", "无法连接到聊天服务器。");
            }

            for (QWidget *widget : QApplication::topLevelWidgets()) {
                if (widget != this) {
                    widget->hide();
                }
            }

            userListPage = new UserListPage(db, account);

            userListPage->setAttribute(Qt::WA_DeleteOnClose);
            userListPage->setGeometry(this->geometry());
            userListPage->show();

            this->hide();
        } else {
            QMessageBox::warning(this, "Login Failed", "Incorrect password.");
        }
    } else {
        QMessageBox::information(this, "Login Failed", "Account does not exist. Please register.");
        showRegisterPage();
    }
}

void SettingsPage::showRegisterPage()
{
    RegisterPage *registerPage = new RegisterPage(db, this);
    connect(registerPage, &RegisterPage::registrationCompleted, this, [=](bool rememberUser){
        if (rememberUser) {
            handleLogin();
        } else {
            this->show();
        }
    });
    connect(registerPage, &RegisterPage::backToLogin, this, &SettingsPage::show);
    registerPage->exec();
}

void SettingsPage::readServerResponse()
{
    while (tcpSocket->canReadLine()) {
        QString response = QString::fromUtf8(tcpSocket->readLine()).trimmed();

        if (userListPage) {
            MyChatPage *chatPage = userListPage->getCurrentChatPage();
            if (chatPage) {
                chatPage->appendMessage(response, false);
            }
        }
    }
}
