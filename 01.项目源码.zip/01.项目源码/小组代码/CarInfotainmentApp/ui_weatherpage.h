/********************************************************************************
** Form generated from reading UI file 'weatherpage.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WEATHERPAGE_H
#define UI_WEATHERPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <define_qlabel.h>

QT_BEGIN_NAMESPACE

class Ui_WeatherPage
{
public:
    QLabel *label_weather_type_1;
    QLabel *label_weather_icon;
    QLabel *label;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    DEFINE_QLABEL *label_local_city;
    QLabel *label_city_name;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_real_time_temp;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_4;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_4;
    DEFINE_QLABEL *label_refresh;
    QSpacerItem *verticalSpacer_2;
    QLabel *label_show_message;

    void setupUi(QWidget *WeatherPage)
    {
        if (WeatherPage->objectName().isEmpty())
            WeatherPage->setObjectName(QString::fromUtf8("WeatherPage"));
        WeatherPage->resize(1280, 720);
        label_weather_type_1 = new QLabel(WeatherPage);
        label_weather_type_1->setObjectName(QString::fromUtf8("label_weather_type_1"));
        label_weather_type_1->setGeometry(QRect(1100, 550, 150, 50));
        QFont font;
        font.setPointSize(23);
        label_weather_type_1->setFont(font);
        label_weather_icon = new QLabel(WeatherPage);
        label_weather_icon->setObjectName(QString::fromUtf8("label_weather_icon"));
        label_weather_icon->setGeometry(QRect(690, 30, 450, 450));
        label = new QLabel(WeatherPage);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(840, 550, 231, 50));
        label->setFont(font);
        horizontalLayoutWidget = new QWidget(WeatherPage);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(190, 40, 321, 171));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_local_city = new DEFINE_QLABEL(horizontalLayoutWidget);
        label_local_city->setObjectName(QString::fromUtf8("label_local_city"));
        QFont font1;
        font1.setPointSize(20);
        label_local_city->setFont(font1);
        label_local_city->setScaledContents(false);

        horizontalLayout->addWidget(label_local_city);

        label_city_name = new QLabel(horizontalLayoutWidget);
        label_city_name->setObjectName(QString::fromUtf8("label_city_name"));
        QFont font2;
        font2.setPointSize(25);
        label_city_name->setFont(font2);

        horizontalLayout->addWidget(label_city_name);

        horizontalLayoutWidget_2 = new QWidget(WeatherPage);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(200, 270, 285, 201));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_real_time_temp = new QLabel(horizontalLayoutWidget_2);
        label_real_time_temp->setObjectName(QString::fromUtf8("label_real_time_temp"));
        QFont font3;
        font3.setPointSize(64);
        label_real_time_temp->setFont(font3);

        horizontalLayout_2->addWidget(label_real_time_temp);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_4 = new QLabel(horizontalLayoutWidget_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QFont font4;
        font4.setPointSize(27);
        label_4->setFont(font4);

        verticalLayout_3->addWidget(label_4);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);


        horizontalLayout_2->addLayout(verticalLayout_3);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_refresh = new DEFINE_QLABEL(horizontalLayoutWidget_2);
        label_refresh->setObjectName(QString::fromUtf8("label_refresh"));
        QFont font5;
        font5.setPointSize(22);
        label_refresh->setFont(font5);

        verticalLayout_4->addWidget(label_refresh);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);


        horizontalLayout_2->addLayout(verticalLayout_4);

        label_show_message = new QLabel(WeatherPage);
        label_show_message->setObjectName(QString::fromUtf8("label_show_message"));
        label_show_message->setGeometry(QRect(100, 560, 681, 78));
        QFont font6;
        font6.setFamily(QString::fromUtf8("Ubuntu Condensed"));
        font6.setPointSize(23);
        font6.setBold(true);
        font6.setItalic(true);
        font6.setWeight(75);
        label_show_message->setFont(font6);
        label_show_message->setTextFormat(Qt::AutoText);

        retranslateUi(WeatherPage);

        QMetaObject::connectSlotsByName(WeatherPage);
    } // setupUi

    void retranslateUi(QWidget *WeatherPage)
    {
        WeatherPage->setWindowTitle(QApplication::translate("WeatherPage", "\345\244\251\346\260\224", nullptr));
        label_weather_type_1->setText(QApplication::translate("WeatherPage", "\346\231\264", nullptr));
        label_weather_icon->setText(QApplication::translate("WeatherPage", "TextLabel", nullptr));
        label->setText(QApplication::translate("WeatherPage", "\344\273\212\346\227\245\345\244\251\346\260\224\357\274\232", nullptr));
        label_local_city->setText(QApplication::translate("WeatherPage", "locate", nullptr));
        label_city_name->setText(QApplication::translate("WeatherPage", "\345\214\227\344\272\254", nullptr));
        label_real_time_temp->setText(QApplication::translate("WeatherPage", "28", nullptr));
        label_4->setText(QApplication::translate("WeatherPage", "\343\200\202", nullptr));
        label_refresh->setText(QApplication::translate("WeatherPage", "C", nullptr));
        label_show_message->setText(QApplication::translate("WeatherPage", "\346\254\242\350\277\216\344\275\277\347\224\250\345\244\251\346\260\224\347\225\214\351\235\242", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WeatherPage: public Ui_WeatherPage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WEATHERPAGE_H
