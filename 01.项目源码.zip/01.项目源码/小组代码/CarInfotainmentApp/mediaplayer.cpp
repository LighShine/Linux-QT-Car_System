#include "mediaplayer.h"

MediaPlayer::MediaPlayer(QObject *parent) : QObject(parent) {
    mediaPlayer = new QMediaPlayer(this);
    playlist = nullptr; // Initialize playlist as nullptr

    // Connect signals and slots
    connect(mediaPlayer, &QMediaPlayer::positionChanged, this, &MediaPlayer::setProgressSlider);
    connect(mediaPlayer, &QMediaPlayer::mediaStatusChanged, this, &MediaPlayer::checkIfEnd);

    // Handle errors using a dedicated slot
    connect(mediaPlayer, QOverload<QMediaPlayer::Error>::of(&QMediaPlayer::error), this, &MediaPlayer::handleError);
}

void MediaPlayer::playMusic(const QString &filePath) {
    qDebug() << "playMusic: Trying to play file at path:" << filePath;

    if (!QFile::exists(filePath)) {
        qDebug() << "File does not exist!";
        return;
    }

    qDebug() << "Encoded path:" << QUrl::fromLocalFile(filePath).toString();

    if (mediaPlayer->state() != QMediaPlayer::PlayingState || filePath != mediaPlayer->media().canonicalUrl().toString()) {
        mediaPlayer->setMedia(QUrl::fromLocalFile(filePath));
    }

    mediaPlayer->play();

    if (mediaPlayer->error() != QMediaPlayer::NoError) {
        qDebug() << "Error playing music: " << mediaPlayer->errorString();
    }
}

void MediaPlayer::pauseMusic() {
    if (mediaPlayer->state() == QMediaPlayer::PlayingState) {
        mediaPlayer->pause();
    }
}

// 实现新的 play() 方法
void MediaPlayer::play() {
    mediaPlayer->play();
}

void MediaPlayer::setMusicProgress(int progressSliderValue) {
    qint64 newPosition = mediaPlayer->duration() * progressSliderValue / 100;
    mediaPlayer->setPosition(newPosition);
}

void MediaPlayer::setMusicVolume(int volume) {
    mediaPlayer->setVolume(volume);
}

bool MediaPlayer::isPlaying() {
    return mediaPlayer->state() == QMediaPlayer::PlayingState;
}

qint64 MediaPlayer::returnPosition() {
    return mediaPlayer->position();
}

qint64 MediaPlayer::returnDuration() {
    return mediaPlayer->duration();
}

void MediaPlayer::handleError(QMediaPlayer::Error error) {
    qDebug() << "Media player encountered an error:" << error << "-" << mediaPlayer->errorString();
}

void MediaPlayer::setProgressSlider() {
    int sliderNumber = static_cast<int>(mediaPlayer->position() * 100 / mediaPlayer->duration());
    emit calculateProgressSliderNumber(sliderNumber);
    emit playPosition(static_cast<int>(mediaPlayer->position() / 1000));
    emit playDuration(static_cast<int>(mediaPlayer->duration() / 1000));
}

void MediaPlayer::checkIfEnd() {
    if (mediaPlayer->mediaStatus() == QMediaPlayer::EndOfMedia) {
        emit musicEnded();
    }
}

void MediaPlayer::endMusic() {
    mediaPlayer->stop();
}

void MediaPlayer::setPlaylist(QMediaPlaylist *playlist) {
    this->playlist = playlist;
    mediaPlayer->setPlaylist(playlist);
}

