#include "weather.h"
#include "weather.h"
#include <QDir>
#include <QFile>
#include <QMessageBox>
#include <QTextCodec>

WEATHER::WEATHER(QObject *parent) : QObject(parent)
{
    setCurrentCity("北京市");
}

void WEATHER::sendNetworkRequest(QString city)
{
    QNetworkRequest request;
    QString url = "https://restapi.amap.com/v3/weather/weatherInfo?";
    QString adcode=getCityIdFromJson(city);

    // 添加 API key 和城市参数
    url.append("key=5b6bb68662a0b28f365af362fc1410cf");
    url.append("&city=" + adcode);  // 使用adcode代替城市名称
    url.append("&extensions=base");  // 返回实况天气
    url.append("&output=JSON");  // 返回JSON格式

    request.setUrl(QUrl(url));

    // 发送 GET 请求
    manager->get(request);
}


QString WEATHER::getCityIdFromJson(QString city)
{
    QJsonParseError error;
    QByteArray      jsonDate;
    QJsonArray      jsonArray;
    QString appPath = QDir::currentPath();
    QString filePath;

    filePath = tr(":/new/prefix1/city.json");

    QFile jsonFile(filePath);

    jsonFile.open(QIODevice::ReadOnly);

    jsonDate = jsonFile.readAll();

    jsonFile.close();

    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonDate, &error);

    if(error.error != QJsonParseError::NoError)
    {
        dbg("json read error",0);
    }


    jsonArray = jsonDoc.array();
    QString cityId;

    for(int i = 0; i < jsonArray.size(); i++)
    {
        QJsonObject dateObj = jsonArray.at(i).toObject();

        if(dateObj.value("中文名").toString().contains(city))
        {
            cityId = dateObj.value("adcode").toString();
            break;
        }
    }

    return cityId;

}

QString WEATHER::getCurrentCity() const
{
    return currentCity;
}

void WEATHER::setCurrentCity(const QString &value)
{
    currentCity = value;
}

void WEATHER::slot_refresh_manually()
{
    sendNetworkRequest(getCurrentCity());
}

void WEATHER::slot_new_obj()
{
    manager = new QNetworkAccessManager();

    weather_info = new WEATHER_INFO;

    timForRefresh = new QTimer(this);

    connect(timForRefresh, SIGNAL(timeout()), this, SLOT(slot_tim_update_weather()));

    /* 解析完成后，通过槽函数获得数据 */
    connect(manager, SIGNAL(finished(QNetworkReply *)), this, SLOT(slot_manager_read_finished(QNetworkReply *)));

    sendNetworkRequest(getCurrentCity());

    timForRefresh->start(1000 * 5 * 60);
}

void WEATHER::slot_manager_read_finished(QNetworkReply *reply)
{
    parsingNetworkResult(reply->readAll());
}

QString WEATHER::getcityName(QJsonObject obj)
{
    QJsonObject cityInfoObj;

    QString cityName;

    cityInfoObj = obj.value("cityInfo").toObject();

    cityName = cityInfoObj.value("city").toString();

    return cityName;
}


void WEATHER::parsingNetworkResult(QByteArray data)
{
    QJsonParseError error;
    QJsonDocument jsonDoc = QJsonDocument::fromJson(data, &error);

    if (error.error != QJsonParseError::NoError)
    {
        dbg("json error", 0);
        return;
    }

    QJsonObject jsonObject = jsonDoc.object();
    QJsonArray livesArray = jsonObject.value("lives").toArray();

    if (livesArray.isEmpty())
    {
        dbg("no lives data", 0);
        return;
    }

    QJsonObject liveData = livesArray.at(0).toObject();

    weather_info->cityName = liveData.value("city").toString();
    dbg("city name:", weather_info->cityName);

    weather_info->realTime.temp = liveData.value("temperature").toString();
    dbg("temp:", weather_info->realTime.temp);

    weather_info->realTime.weatherType = liveData.value("weather").toString();
    dbg("weather type:", weather_info->realTime.weatherType);

    weather_info->realTime.windDirection = liveData.value("winddirection").toString();
    dbg("wind direction:", weather_info->realTime.windDirection);

    weather_info->realTime.windPower = liveData.value("windpower").toString();
    dbg("wind power:", weather_info->realTime.windPower);

    weather_info->realTime.humidity = liveData.value("humidity").toString();
    dbg("humidity:", weather_info->realTime.humidity);

    weather_info->realTime.updateTime = liveData.value("reporttime").toString();
    dbg("update time:", weather_info->realTime.updateTime);

    emit signal_emit_weather_info(weather_info);
}


void WEATHER::slot_change_local_city(QString cityName)
{
    setCurrentCity(cityName);

    sendNetworkRequest(getCurrentCity());

}


void WEATHER::slot_tim_update_weather()
{
    sendNetworkRequest(getCurrentCity());
}

