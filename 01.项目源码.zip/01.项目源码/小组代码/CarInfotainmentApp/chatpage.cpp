#include "chatpage.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QMessageBox>
#include <QProcess>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QWebEngineView>
#include <QFile>
#include <QUrl>
#include <QTableWidget>
#include <QHeaderView>

ChatPage::ChatPage(QWidget *parent) : QWidget(parent) {
    // 设置整个窗口的最小尺寸
    this->setMinimumSize(1280, 720); // 调高窗口高度

    QVBoxLayout *layout = new QVBoxLayout(this);

    // 设置背景颜色和全局样式
    this->setStyleSheet("background-color: #BA55D3; color: #333333; font-family: 'Arial';");

    // 初始化 QWebEngineView 用于显示小幽灵动画
    webView = new QWebEngineView(this);
    webView->setFixedHeight(135); // 设置幽灵动画的高度
    webView->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed); // 使宽度适应窗口

    QUrl url("qrc:/html/ghost.html");
    webView->setUrl(url); // 使用资源文件中的 HTML

    // 设置聊天历史框
    chatHistory = new QTextEdit(this);
    chatHistory->setReadOnly(true);
        chatHistory->setStyleSheet("background-color: #FFFAFA; color: #333333; font-size: 14px; border-radius: 8px; padding: 10px;");
        chatHistory->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding); // 使聊天历史框占据更高的窗口空间

    // 设置输入框和按钮
    inputField = new QLineEdit(this);
    inputField->setStyleSheet("background-color: #FFFFFF; color: #333333; padding: 10px; border-radius: 8px; border: 1px solid #CCCCCC;");

    sendButton = new QPushButton("发送", this);
    sendButton->setStyleSheet("background-color: #D8BFD8; color: #333333; padding: 10px 20px; border-radius: 8px; border: none; font-size: 14px;");

    backButton = new QPushButton("返回主页", this);
    backButton->setStyleSheet("background-color: #D8BFD8; color: #333333; padding: 10px 20px; border-radius: 8px; border: none; font-size: 14px;");

    QHBoxLayout *inputLayout = new QHBoxLayout;
    inputLayout->addWidget(inputField);
    inputLayout->addWidget(sendButton);

    // 将元素添加到布局
    layout->addWidget(webView);     // 放置幽灵动画
    layout->addWidget(chatHistory); // 放置聊天历史框
    layout->addLayout(inputLayout); // 放置输入框和发送按钮
    layout->addWidget(backButton);  // 放置返回按钮

    // 连接信号和槽
    connect(sendButton, &QPushButton::clicked, this, &ChatPage::sendMessage);
    connect(backButton, &QPushButton::clicked, this, &ChatPage::goHome);

    setLayout(layout);
    initChatHistory();
}

void ChatPage::initChatHistory() {
    chatHistory->append("<b style='color: #9370DB;'>小治:</b> 有什么可以帮到您的？");
}

void ChatPage::sendMessage() {
    QString userMessage = inputField->text();
    if (userMessage.isEmpty()) {
        return;
    }

    chatHistory->append("<b style='color: #B0E0E6;'>你:</b> " + userMessage);
    inputField->clear();

    QProcess *process = new QProcess(this);
    QString script = R"(
import requests
import json

def get_access_token():
    url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {
        "grant_type": "client_credentials",
        "client_id": "h1ylVRDvEGY4Ypjs6bxoqz2z",  # 替换为你在百度AI平台上获得的API_KEY
        "client_secret": "KxIHeDdgtY43aiPjM64scY4n3HY61TK3"  # 替换为你在百度AI平台上获得的SECRET_KEY
    }

    response = requests.post(url, params=params)

    if response.status_code == 200:
        access_token = response.json().get('access_token')
        return access_token
    else:
        print(f"获取 access_token 失败: {response.text}")
        return None

def sentiment_analysis(text, access_token):
    url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/ernie_speed?access_token=" + access_token

    headers = {
        'Content-Type': 'application/json'
    }

    data = {
        "messages": [
            {"role": "user", "content": text}
        ]
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))

    if response.status_code == 200:
        result = response.json()
        return result
    else:
        print(f"调用NLP API失败: {response.text}")
        return None

token = get_access_token()
if token:
    text = '<用户输入的文本>'
    result = sentiment_analysis(text, token)
    print(json.dumps(result, ensure_ascii=False, indent=4))
    )";

    script.replace("<用户输入的文本>", userMessage);

    process->start("python3", QStringList() << "-c" << script);

    connect(process, &QProcess::readyReadStandardOutput, this, [this, process]() {
        QString response = process->readAllStandardOutput().trimmed();
        if (!response.isEmpty()) {
            QJsonDocument jsonResponse = QJsonDocument::fromJson(response.toUtf8());
            if (!jsonResponse.isNull() && jsonResponse.isObject()) {
                QJsonObject jsonObject = jsonResponse.object();
                QString result = jsonObject["result"].toString();
                chatHistory->append("<b style='color: #9370DB;'>小治:</b> " + result);
            } else {
                chatHistory->append("获取响应失败：无法解析JSON");
            }
        } else {
            chatHistory->append("获取响应失败");
        }
        process->deleteLater();
    });
}
