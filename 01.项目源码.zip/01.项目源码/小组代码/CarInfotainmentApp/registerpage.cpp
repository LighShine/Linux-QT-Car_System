#include "registerpage.h"
#include "clickablelabel.h"  // 引入自定义的ClickableLabel类
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QFileDialog>
#include <QDebug>
#include <QPainter>
RegisterPage::RegisterPage(QSqlDatabase &db, QWidget *parent) : QDialog(parent), db(db)
{
    setupUI();
}

RegisterPage::~RegisterPage()
{
    // 保持数据库连接
}

void RegisterPage::setupUI()
{
    setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint);
    setAttribute(Qt::WA_DeleteOnClose);
    setFixedSize(450, 650);

    QPalette palette;
    QLinearGradient gradient(0, 0, 0, height());
    gradient.setColorAt(0, QColor("#f8b6c2"));  // 渐变的起始颜色（浅粉色）
    gradient.setColorAt(1, QColor("#ffe6e9"));  // 渐变的结束颜色（更浅的粉色）
    palette.setBrush(QPalette::Window, gradient);
    setPalette(palette);

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setContentsMargins(20, 20, 20, 20);

    QLabel *titleLabel = new QLabel("注册", this);
    titleLabel->setStyleSheet("font-size: 26px; font-weight: bold; color: #333333;");  // 使用深色字体
    titleLabel->setAlignment(Qt::AlignCenter);

    avatarLabel = new ClickableLabel(this);  // 使用ClickableLabel
    avatarLabel->setFixedSize(100, 100);
    avatarLabel->setStyleSheet("border: 2px solid #333333; border-radius: 50px; background-color: #ffffff;");
    avatarLabel->setAlignment(Qt::AlignCenter);
    avatarLabel->setPixmap(QPixmap(":/path/to/default_avatar.png").scaled(avatarLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));

    connect(avatarLabel, &ClickableLabel::clicked, this, &RegisterPage::chooseAvatar); // 使用自定义信号

    nameField = new QLineEdit(this);
    nameField->setPlaceholderText("用户名");
    nameField->setStyleSheet("background-color: transparent; color: #333333; font-size: 14px; border: none; border-bottom: 1px solid #333333; padding: 10px; margin-bottom: 20px;");

    accountField = new QLineEdit(this);
    accountField->setPlaceholderText("账号");
    accountField->setStyleSheet("background-color: transparent; color: #333333; font-size: 14px; border: none; border-bottom: 1px solid #333333; padding: 10px; margin-bottom: 20px;");

    passwordField = new QLineEdit(this);
    passwordField->setEchoMode(QLineEdit::Password);
    passwordField->setPlaceholderText("设置密码");
    passwordField->setStyleSheet("background-color: transparent; color: #333333; font-size: 14px; border: none; border-bottom: 1px solid #333333; padding: 10px; margin-bottom: 20px;");

    confirmPasswordField = new QLineEdit(this);
    confirmPasswordField->setEchoMode(QLineEdit::Password);
    confirmPasswordField->setPlaceholderText("确认密码");
    confirmPasswordField->setStyleSheet("background-color: transparent; color: #333333; font-size: 14px; border: none; border-bottom: 1px solid #333333; padding: 10px; margin-bottom: 20px;");

    rememberMeCheckBox = new QCheckBox("记住我", this);
    rememberMeCheckBox->setStyleSheet("color: #333333; font-size: 12px;");

    submitButton = new QPushButton("注册", this);
    submitButton->setStyleSheet("background-color: #ff92a3; color: white; padding: 10px; font-size: 14px; border-radius: 20px; margin-top: 30px; border: none;");
    connect(submitButton, &QPushButton::clicked, this, &RegisterPage::handleRegister);

    backButton = new QPushButton("返回", this);
    backButton->setStyleSheet("background-color: #666; color: white; padding: 10px; font-size: 14px; border-radius: 20px; border: none;");
    connect(backButton, &QPushButton::clicked, this, &RegisterPage::goBackToLogin);

    QLabel *loginPrompt = new QLabel("已经有账号了？<a href='#'>登录</a>", this);
    loginPrompt->setStyleSheet("color: #333333; font-size: 12px;");
    loginPrompt->setAlignment(Qt::AlignCenter);

    layout->addWidget(titleLabel);
    layout->addWidget(avatarLabel, 0, Qt::AlignHCenter);
    layout->addWidget(nameField);
    layout->addWidget(accountField);
    layout->addWidget(passwordField);
    layout->addWidget(confirmPasswordField);
    layout->addWidget(rememberMeCheckBox);
    layout->addWidget(submitButton);
    layout->addWidget(backButton);
    layout->addWidget(loginPrompt);
    layout->setAlignment(Qt::AlignTop);

    setLayout(layout);
}
void RegisterPage::chooseAvatar()
{
    QFileDialog fileDialog(this, tr("选择头像"), QString(), tr("Images (*.png *.xpm *.jpg)"));
    fileDialog.setOption(QFileDialog::DontUseNativeDialog);  // 禁用原生文件对话框

    if (fileDialog.exec() == QDialog::Accepted) {
        QString filePath = fileDialog.selectedFiles().first();
        if (!filePath.isEmpty()) {
            avatarPath = filePath;
            QPixmap pixmap(filePath);

            // 裁剪成圆形
            QPixmap circularPixmap(avatarLabel->size());
            circularPixmap.fill(Qt::transparent); // 填充透明背景

            QPainterPath path;
            path.addEllipse(0, 0, avatarLabel->width(), avatarLabel->height());

            QPainter painter(&circularPixmap);
            painter.setRenderHint(QPainter::Antialiasing);
            painter.setClipPath(path);
            painter.drawPixmap(0, 0, pixmap.scaled(avatarLabel->size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));

            avatarLabel->setPixmap(circularPixmap);
        }
    }
}


void RegisterPage::handleRegister()
{
    if (accountField->text().isEmpty() || nameField->text().isEmpty() || passwordField->text().isEmpty() || confirmPasswordField->text().isEmpty()) {
        QMessageBox::warning(this, "Input Error", "所有字段必须填写。");
        return;
    }

    if (passwordField->text() != confirmPasswordField->text()) {
        QMessageBox::warning(this, "Input Error", "两次输入的密码不一致。");
        return;
    }

    QSqlQuery query(db);
    query.prepare("INSERT INTO users (account, password, username, avatar) VALUES (:account, :password, :username, :avatar)");
    query.bindValue(":account", accountField->text());
    query.bindValue(":password", passwordField->text());
    query.bindValue(":username", nameField->text());
    query.bindValue(":avatar", avatarPath.isEmpty() ? QVariant(QVariant::String) : avatarPath);

    if (query.exec()) {
        QMessageBox::information(this, "Success", "注册成功！");
        emit registrationCompleted(rememberMeCheckBox->isChecked());
        this->close();
    } else {
        QMessageBox::warning(this, "Error", "无法注册用户: " + query.lastError().text());
    }
}

void RegisterPage::goBackToLogin()
{
    emit backToLogin();
    close();
}
