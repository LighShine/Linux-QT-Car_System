#include "userlistpage.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QListWidgetItem>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPixmap>
#include <QFile>
#include <QPushButton>
#include <QDebug>
#include "settingspage.h"

UserListPage::UserListPage(QSqlDatabase &db, const QString &currentAccount, QWidget *parent)
    : QWidget(parent), db(db), currentAccount(currentAccount), currentChatPage(nullptr)
{
    setupUI();
    loadUserData();

    connect(userListWidget, &QListWidget::itemClicked, this, &UserListPage::onUserClicked);
}

UserListPage::~UserListPage()
{
}

void UserListPage::setupUI()
{
    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    QWidget *titleBar = new QWidget(this);
    QHBoxLayout *titleLayout = new QHBoxLayout(titleBar);
    titleBar->setFixedHeight(70);
    titleBar->setStyleSheet(
        "background-color: #f0f0f0;"
        "border-bottom: 1px solid #dcdcdc;"
        "padding: 10px;"
    );

    QPushButton *backButton = new QPushButton(QIcon(":/icons/back.png"), "", this);
    backButton->setFixedSize(40, 40);
    backButton->setStyleSheet("border: none; background-color: transparent;");

    QLabel *titleLabel = new QLabel("用户列表", this);
    titleLabel->setStyleSheet(
        "font-size: 24px;"
        "color: #2c3e50;"
        "font-weight: bold;"
    );

    QPushButton *settingsButton = new QPushButton(QIcon(":/icons/settings.png"), "", this);
    settingsButton->setFixedSize(40, 40);
    settingsButton->setStyleSheet("border: none; background-color: transparent;");

    // 设置“退出登录”按钮样式
    logoutButton = new QPushButton("退出登录", this);
    logoutButton->setFixedSize(100, 40);
    logoutButton->setStyleSheet(
        "background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
        "stop:0 rgba(255, 105, 180, 0.8), stop:1 rgba(255, 182, 193, 0.8));"  // 渐变色从浅粉色到深粉色，并增加透明度
        "color: white;"
        "border: none;"
        "border-radius: 20px;"
        "font-size: 16px;"
        "padding: 10px;"
        "font-weight: bold;"
    );
    connect(logoutButton, &QPushButton::clicked, this, &UserListPage::handleLogout);

    titleLayout->addWidget(backButton);
    titleLayout->addStretch();
    titleLayout->addWidget(titleLabel);
    titleLayout->addStretch();
    titleLayout->addWidget(settingsButton);
    titleLayout->addWidget(logoutButton);

    titleBar->setLayout(titleLayout);

    userListWidget = new QListWidget(this);
    userListWidget->setStyleSheet(
        "background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
        "stop:0 rgba(255, 255, 224, 0.9), stop:1 rgba(255, 250, 240, 0.9));"
        "border: 0px; padding: 10px;"
    );

    mainLayout->addWidget(titleBar);
    mainLayout->addWidget(userListWidget);
    setLayout(mainLayout);
}

void UserListPage::loadUserData()
{
    if (!db.isOpen()) {
        QMessageBox::critical(this, "Database Error", "Database is not open!");
        return;
    }

    QSqlQuery query(db);
    query.prepare("SELECT username, avatar FROM users");

    if (!query.exec()) {
        QMessageBox::critical(this, "Database Error", "Failed to fetch user data: " + query.lastError().text());
        qDebug() << "Error executing query:" << query.lastError().text();
        return;
    }

    while (query.next()) {
        QString username = query.value(0).toString();
        QString avatarPath = query.value(1).toString();

        QListWidgetItem *item = new QListWidgetItem(userListWidget);
        item->setSizeHint(QSize(userListWidget->width() - 20, 120)); // 调整气泡框高度，并给气泡框设置宽度，便于间距设置
        item->setData(Qt::UserRole, username);

        QWidget *itemWidget = new QWidget();
        QHBoxLayout *bubbleLayout = new QHBoxLayout(itemWidget);
        bubbleLayout->setContentsMargins(20, 15, 20, 15);  // 增加气泡框的内边距
        bubbleLayout->setSpacing(15);

        QLabel *avatarLabel = new QLabel(itemWidget);
        avatarLabel->setFixedSize(60, 60);  // 更大的圆形头像
        avatarLabel->setStyleSheet("border-radius: 30px; background-color: transparent;");  // 圆形头像，无背景色
        if (!avatarPath.isEmpty() && QFile::exists(avatarPath)) {
            QPixmap avatarPixmap(avatarPath);
            avatarLabel->setPixmap(avatarPixmap.scaled(avatarLabel->size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
        } else {
            avatarLabel->setPixmap(QPixmap(":/path/to/default_avatar.png").scaled(avatarLabel->size(), Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
        }

        QLabel *usernameLabel = new QLabel(username, itemWidget);
        usernameLabel->setStyleSheet("font-size: 18px; color: #333; font-weight: bold; background-color: transparent;");  // 去掉边框样式和背景色

        QLabel *iconLabel = new QLabel(itemWidget);
        iconLabel->setFixedSize(24, 24);
        iconLabel->setPixmap(QPixmap(":/icons/some_icon.png").scaled(iconLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));  // 添加图标

        bubbleLayout->addWidget(avatarLabel);
        bubbleLayout->addWidget(usernameLabel);
        bubbleLayout->addStretch();  // 用于将图标放到右侧
        bubbleLayout->addWidget(iconLabel);

        // 使用新的渐变背景的样式
        itemWidget->setStyleSheet(
            "background: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, "
            "stop:0 rgba(255, 255, 255, 0.6), stop:1 rgba(54, 100, 139, 0.9));"
            "border-radius: 20px; "
            "padding: 10px;"
        );

        itemWidget->setLayout(bubbleLayout);

        userListWidget->addItem(item);
        userListWidget->setItemWidget(item, itemWidget);
    }

    // 为用户框之间增加间距
    userListWidget->setSpacing(10);
}

void UserListPage::onUserClicked(QListWidgetItem *item)
{
    QString username = item->data(Qt::UserRole).toString();
    if (currentChatPage) {
        currentChatPage->close();
        delete currentChatPage;
    }
    currentChatPage = new MyChatPage(currentAccount, username, db);  // 传递数据库引用
    currentChatPage->setAttribute(Qt::WA_DeleteOnClose);
    currentChatPage->setGeometry(this->geometry());
    connect(currentChatPage, &MyChatPage::backToUserList, this, &UserListPage::show);  // 连接返回信号
    currentChatPage->show();
    this->hide();  // 隐藏用户列表页面
}

void UserListPage::handleLogout()
{
    emit logout();  // 发射退出登录信号

        // 直接创建新的 SettingsPage 实例
        SettingsPage *loginPage = new SettingsPage();
        loginPage->setGeometry(this->geometry());  // 可选：设置位置与大小
        loginPage->show();

        this->close();  // 关闭当前 UserListPage
}

MyChatPage* UserListPage::getCurrentChatPage() const
{
    return currentChatPage;
}
